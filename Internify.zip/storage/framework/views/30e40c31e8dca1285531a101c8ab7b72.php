<?php $__env->startSection('content'); ?>
    <div class="container">
        <form method="POST" action="<?php echo e(route('mahasiswa.update', $mahasiswa->mahasiswa_id ?? $mahasiswa->id)); ?>">
            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>

            <div class="mb-3">
                <label>Nama</label>
                <input type="text" name="name" class="form-control"
                    value="<?php echo e(old('name', $mahasiswa->user->name ?? '')); ?>" required>
            </div>

            <div class="mb-3">
                <label>Username</label>
                <input type="text" name="username" class="form-control"
                    value="<?php echo e(old('username', $mahasiswa->user->username ?? '')); ?>" required>
            </div>

            <div class="mb-3">
                <label>Email</label>
                <input type="text" name="email" class="form-control"
                    value="<?php echo e(old('email', $mahasiswa->user->email ?? '')); ?>" required>
            </div>

            <div class="mb-3">
                <label>Password (kosongkan jika tidak diubah)</label>
                <input type="password" name="password" class="form-control">
            </div>

            <div class="mb-3">
                <label>NIM</label>
                <input type="text" name="nim" class="form-control" value="<?php echo e(old('nim', $mahasiswa->nim ?? '')); ?>"
                    required>
            </div>

            <div class="mb-3">
                <label>Alamat</label>
                <input type="text" name="alamat" class="form-control"
                    value="<?php echo e(old('alamat', $mahasiswa->alamat ?? '')); ?>" required>
            </div>

            <div class="mb-3">
                <label>Jurusan</label>
                <select name="prodi_id" class="form-control" required>
                    <?php $__currentLoopData = $prodis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prodi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($prodi->prodi_id); ?>"
                            <?php echo e(old('prodi_id') == $prodi->prodi_id || $prodi->prodi_id == $mahasiswa->prodi_id ? 'selected' : ''); ?>>
                            <?php echo e($prodi->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <button class="btn btn-primary">Update</button>
            <a href="<?php echo e(route('mahasiswa.index')); ?>" class="btn btn-secondary">Kembali</a>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\raki\Documents\raki4\pbl\Internify\resources\views/mahasiswa/edit.blade.php ENDPATH**/ ?>