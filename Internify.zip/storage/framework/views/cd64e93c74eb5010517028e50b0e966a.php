<?php $__env->startSection('content'); ?>
<div class="container">
    <form action="<?php echo e(route('prodi.update', $prodi->prodi_id ?? $prodi->prodi_id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label>ID Prodi</label>
            <input type="text" name="prodi_id" value="<?php echo e($prodi->prodi_id); ?>" class="form-control" readonly>
        </div>
        
        <div class="form-group mt-2">
            <label>Nama Prodi</label>
            <input type="text" name="name" value="<?php echo e($prodi->name); ?>" class="form-control" required>
        </div>

        <button type="submit" class="btn btn-success mt-3">Simpan</button>
        <a href="<?php echo e(route('prodi.index')); ?>" class="btn btn-secondary mt-3">Kembali</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\raki\Documents\raki4\pbl\Internify\resources\views/prodi/edit.blade.php ENDPATH**/ ?>