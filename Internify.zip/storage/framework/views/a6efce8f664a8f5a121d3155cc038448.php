<?php $__env->startSection('content'); ?>
    <div class="card card-bordered">
        <div class="card-inner">
            <form method="POST" action="<?php echo e(route('company.sertifikatMagang.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <input type="text" name="company_id" value="<?php echo e(Auth::user()->company->company_id); ?>" hidden>

                

                <div class="col-md-6">
                    <div class="form-group">
                        <label class="form-label">Judul Sertifikat</label>
                        <select name="judul" id="judul" class="form-control" data-search="on" required>
                            <option value="">- Pilih Lowongan -</option>
                            <?php $__currentLoopData = $lowongans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lowongan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($lowongan->title); ?>"><?php echo e($lowongan->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <br>
                <div class="form-group">
                    <label for="deskripsi">Deskripsi</label>
                    <textarea name="deskripsi" class="form-control"></textarea>
                </div>

                
                <div class="col-12 text-end">
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">Upload</button>
                        <a href="<?php echo e(route('company.sertifikatMagang.index')); ?>" class="btn btn-secondary">Kembali</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\raki\Documents\raki4\pbl\raki\Internify\resources\views/company/sertifikatMagang/create.blade.php ENDPATH**/ ?>