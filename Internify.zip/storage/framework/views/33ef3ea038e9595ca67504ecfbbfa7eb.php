<?php use Illuminate\Support\Str; ?>
<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="card card-bordered card-preview">
        <div class="card-inner">
            <table class="datatable-init-export nowrap nk-tb-list nk-tb-ulist" data-auto-responsive="false">
                <thead>
                    <tr class="nk-tb-item nk-tb-head">
                        <th class="nk-tb-col export-col"><span class="sub-text">ID</span></th>
                        <th class="nk-tb-col export-col"><span class="sub-text">Mahasiswa</span></th>
                        <th class="nk-tb-col export-col"><span class="sub-text">Perusahaan</span></th>
                        <th class="nk-tb-col export-col"><span class="sub-text">Evaluasi</span></th>
                        <th class="nk-tb-col nk-tb-col-tools text-end"><span class="sub-text">Aksi</span></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $evaluasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="nk-tb-item">
                            <td class="nk-tb-col">
                                <span><?php echo e($loop->iteration); ?></span>
                            </td>
                            <td class="nk-tb-col">
                                <div class="user-info">
                                    <span><?php echo e($e->mahasiswa->user->name ?? '-'); ?></span>
                                </div>
                            </td>
                            <td class="nk-tb-col">
                                <span><?php echo e($e->company->user->name ?? '-'); ?></span>
                            </td>
                            <td class="nk-tb-col">
                                <span><?php echo Str::limit(strip_tags($e->evaluasi), 50); ?></span>
                            </td>
                            <td class="nk-tb-col nk-tb-col-tools">
                                <ul class="nk-tb-actions gx-1">
                                    <li>
                                        <div class="drodown">
                                            <a href="#" class="dropdown-toggle btn btn-icon btn-trigger"
                                                data-bs-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                            <div class="dropdown-menu dropdown-menu-end">
                                                <ul class="link-list-opt no-bdr">
                                    <li><a href="<?php echo e(route('evaluasi.edit', $e->evaluasi_id)); ?>">
                                            <em class="icon ni ni-edit"></em>
                                            <span>Edit</span>
                                        </a>
                                    </li>
                                    <li class="divider"></li>
                                    <li>
                                        <form action="<?php echo e(route('evaluasi.destroy', $e)); ?>" method="POST"
                                            onsubmit="return confirm('Yakin ingin menghapus laporan ini?')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-link text-danger"><em
                                                    class="icon ni ni-trash"></em><span>Hapus</span></button>
                                        </form>
                                    </li>
                                </ul>
        </div>
    </div>
    </li>
    </ul>
    </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    </table>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\raki\Documents\raki4\pbl\raki\Internify\resources\views/dosen/evaluasi/index.blade.php ENDPATH**/ ?>