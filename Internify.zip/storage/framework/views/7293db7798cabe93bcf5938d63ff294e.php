<?php if(Auth::user()->level->level_nama == 'Administrator'): ?>
    <li class="nk-menu-heading">
        <h6 class="overline-title text-primary-alt">Dashboards</h6>
    </li>
    <!-- .nk-menu-heading -->
    <li class="nk-menu-item">
        <a href="<?php echo e(route('admin.dashboard')); ?>" class="nk-menu-link">
            <span class="nk-menu-icon">
                <em class="icon ni ni-dashlite"></em>
            </span>
            <span class="nk-menu-text">Dashboard</span>
        </a>
    </li>
    <!-- .nk-menu-item -->
    <li class="nk-menu-heading">
        <h6 class="overline-title text-primary-alt">Pages</h6>
    </li>
    <!-- .nk-menu-heading -->
    <li class="nk-menu-item has-sub">
        <a href="<?php echo e(route('mahasiswa.index')); ?>" class="nk-menu-link">
            <span class="nk-menu-icon">
                <em class="icon ni ni-users"></em>
            </span>
            <span class="nk-menu-text">Mahasiswa</span>
        </a>
        <!-- .nk-menu-sub -->
    </li>
    <li class="nk-menu-item has-sub">
        <a href="<?php echo e(route('dosen.index')); ?>" class="nk-menu-link">
            <span class="nk-menu-icon">
                <em class="icon ni ni-users"></em>
            </span>
            <span class="nk-menu-text">Dosen</span>
        </a>
        <!-- .nk-menu-sub -->
    </li>
    <li class="nk-menu-item">
        <a href="<?php echo e(route('companies.index')); ?>" class="nk-menu-link">
            <span class="nk-menu-icon">
                <em class="icon ni ni-building"></em>
            </span>
            <span class="nk-menu-text">Companies</span>
        </a>
    </li>
    <li class="nk-menu-item">
        <a href="<?php echo e(route('periodeMagang.index')); ?>" class="nk-menu-link">
            <span class="nk-menu-icon">
                <em class="icon ni ni-calendar"></em>
            </span>
            <span class="nk-menu-text">Periode Magang</span>
        </a>
    </li>
    <li class="nk-menu-item">
        <a href="<?php echo e(route('lowonganMagang.index')); ?>" class="nk-menu-link">
            <span class="nk-menu-icon">
                <em class="icon ni ni-briefcase"></em>
            </span>
            <span class="nk-menu-text">Lowongan Magang</span>
        </a>
    </li>
    <li class="nk-menu-item">
        <a href="<?php echo e(route('magangApplication.index')); ?>" class="nk-menu-link">
            <span class="nk-menu-icon">
                <em class="icon ni ni-file-text"></em>
            </span>
            <span class="nk-menu-text">Lamaran Magang</span>
        </a>
    </li>
    <li class="nk-menu-item has-sub">
        <a href="<?php echo e(route('prodi.index')); ?>" class="nk-menu-link">
            <span class="nk-menu-icon">
                <em class="icon ni ni-comments"></em>
            </span>
            <span class="nk-menu-text">Prodi</span>
        </a>
        <!-- .nk-menu-sub -->
    </li>
<?php endif; ?>
<?php if(Auth::user()->level->level_nama == 'Dosen'): ?>
    <li class="nk-menu-heading">
        <h6 class="overline-title text-primary-alt">Dashboards</h6>
    </li>
    <!-- .nk-menu-heading -->
    <li class="nk-menu-item">
        <a href="<?php echo e(route('dosen.dashboard')); ?>" class="nk-menu-link">
            <span class="nk-menu-icon">
                <em class="icon ni ni-dashlite"></em>
            </span>
            <span class="nk-menu-text">Dashboard</span>
        </a>
    </li>
    <!-- .nk-menu-item -->
<?php endif; ?>
<?php if(Auth::user()->level->level_nama == 'Mahasiswa'): ?>
    <li class="nk-menu-heading">
        <h6 class="overline-title text-primary-alt">Dashboards</h6>
    </li>
    <!-- .nk-menu-heading -->
    <li class="nk-menu-item">
        <a href="<?php echo e(route('mahasiswa.dashboard')); ?>" class="nk-menu-link">
            <span class="nk-menu-icon">
                <em class="icon ni ni-dashlite"></em>
            </span>
            <span class="nk-menu-text">Dashboard</span>
        </a>
    </li>
    <li class="nk-menu-item">
        <a href="<?php echo e(route('lowonganMagang.indexMhs')); ?>" class="nk-menu-link">
            <span class="nk-menu-icon">
                <em class="icon ni ni-briefcase"></em>
            </span>
            <span class="nk-menu-text">Lowongan Magang</span>
        </a>
    </li>
    <li class="nk-menu-item">
        <a href="<?php echo e(route('lamaran')); ?>" class="nk-menu-link">
            <span class="nk-menu-icon">
                <em class="icon ni ni-file-text"></em>
            </span>
            <span class="nk-menu-text">Lamaran Magang</span>
        </a>
    </li>


    <!-- .nk-menu-item -->
<?php endif; ?>
<?php /**PATH C:\Users\raki\Documents\raki4\pbl\Internify\resources\views/layouts/menu.blade.php ENDPATH**/ ?>