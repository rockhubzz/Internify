<!DOCTYPE html>
<html lang="zxx" class="js">

<head>
    <base href="../">
    <meta charset="utf-8">
    <meta name="author" content="Softnio">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description"
        content="A powerful and conceptual apps base dashboard template that especially build for developers and programmers.">
    <!-- Fav Icon  -->
    <link rel="shortcut icon" href="<?php echo e(asset('assets/admin/images/icon.png')); ?>">
    <!-- Page Title  -->
    <title><?php echo e(config('app.name', 'Point of Sales')); ?></title>

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- StyleSheets  -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/dashlite.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/editors/quill.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/editors/quill.rtl.css')); ?>">
    <link id="skin-default" rel="stylesheet" href="<?php echo e(asset('assets/admin/css/theme.css')); ?>">
    @livewireStyles
    

    <style>
        .star-rating {
            direction: rtl;
            font-size: 1.8rem;
            unicode-bidi: bidi-override;
            display: inline-flex;
        }
        .star-rating input[type="radio"] {
            display: none;
        }
        .star-rating label {
            color: #ddd;
            cursor: pointer;
            padding: 0 5px;
            transition: color 0.2s;
        }
        .star-rating input[type="radio"]:checked ~ label,
        .star-rating label:hover,
        .star-rating label:hover ~ label {
            color: #f5b301;
        }
    </style>

    <?php echo $__env->yieldPushContent('css'); ?>
</head>

<body class="nk-body bg-lighter npc-general has-sidebar ">
    <div class="nk-app-root">
        <!-- main @s -->
        <div class="nk-main ">
            <!-- sidebar @s -->
            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- sidebar @e -->
            <!-- wrap @s -->
            <div class="nk-wrap ">
                <!-- main header @s -->
                <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- main header @e -->
                <!-- content @s -->
                <div class="nk-content ">
                    <div class="container-fluid">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
                                <div class="nk-block-head nk-block-head-sm">
                                    <div class="nk-block-between">
                                        <?php echo $__env->make('layouts.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <!-- .nk-block-head-content -->
                                    </div>
                                    <!-- .nk-block-between -->
                                </div>
                                <!-- .nk-block-head -->
                                <?php echo $__env->yieldContent('content'); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- content @e -->
                <!-- footer @s -->
                <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- footer @e -->
            </div>
            <!-- wrap @e -->
        </div>
        <!-- main @e -->
    </div>
    <!-- app-root @e -->
    <!-- JavaScript -->
    <script src="<?php echo e(asset('assets/admin/js/bundle.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/scripts.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/charts/gd-default.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/libs/datatable-btns.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/example-sweetalert.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/example-toastr.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/editors/quill.css')); ?>">
    <script src="<?php echo e(asset('assets/admin/js/libs/editors/quill.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/editors.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/libs/tagify.js')); ?>"></script>
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>
    @livewireScripts
    <?php echo $__env->yieldPushContent('js'); ?>
</body>

</html>
<?php /**PATH C:\Users\raki\Documents\raki4\pbl\raki\Internify\resources\views/layouts/app.blade.php ENDPATH**/ ?>