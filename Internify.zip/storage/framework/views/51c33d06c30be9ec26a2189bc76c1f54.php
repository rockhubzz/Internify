<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>
    <div class="card card-bordered card-preview">
        <div class="card-inner">
            <table class="datatable-init-export nk-tb-list nk-tb-ulist" style="width: 100%; table-layout: auto;">
                <thead>
                    <tr class="nk-tb-item nk-tb-head">
                        <th class="nk-tb-col"><span class="sub-text">Perusahaan</span></th>
                        <th class="nk-tb-col"><span class="sub-text">Judul</span></th>
                        <th class="nk-tb-col"><span class="sub-text">Deskripsi</span></th>
                        <th class="nk-tb-col"><span class="sub-text">Kriteria</span></th>
                        <th class="nk-tb-col"><span class="sub-text">Status</span></th>
                        <th class="nk-tb-col nk-tb-col-tools text-end"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $logang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $mahasiswaId = Auth::user()->mahasiswa->mahasiswa_id ?? null;
                            $lamaran = \App\Models\MagangApplication::where('mahasiswa_id', $mahasiswaId)
                                ->where('lowongan_id', $item->lowongan_id)
                                ->first();
                        ?>
                        <tr class="nk-tb-item">
                            <td class="nk-tb-col" style="white-space: normal; word-wrap: break-word;">
                                <span><?php echo e($item->company->user->name); ?></span>
                            </td>
                            <td class="nk-tb-col" style="white-space: normal; word-wrap: break-word;">
                                <span><?php echo e($item->title); ?></span>
                            </td>
                            <td class="nk-tb-col" style="white-space: normal; word-wrap: break-word; max-width: 250px;">
                                <span><?php echo e(Str::limit($item->description, 30)); ?></span>
                            </td>
                            <td class="nk-tb-col" style="white-space: normal; word-wrap: break-word; max-width: 250px;">
                                <span><?php echo e(Str::limit($item->requirements, 30)); ?></span>
                            </td>

                            <td class="nk-tb-col">
                                <?php if($lamaran): ?>
                                    <?php if($lamaran->status === 'Disetujui'): ?>
                                        <span class="badge bg-success">Diterima</span>
                                    <?php elseif($lamaran->status === 'Ditolak'): ?>
                                        <span class="badge bg-danger">Ditolak</span>
                                    <?php else: ?>
                                        <span class="badge bg-warning text-dark">Pending</span>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </td>
                            <td class="nk-tb-col nk-tb-col-tools">
                                <ul class="nk-tb-actions gx-1">
                                    <li>
                                        <div class="drodown">
                                            <a href="#" class="dropdown-toggle btn btn-icon btn-trigger"
                                                data-bs-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                            <div class="dropdown-menu dropdown-menu-end">
                                                <ul class="link-list-opt no-bdr">
                                                    <li>
                                                        <a href="<?php echo e(route('show.lowongan', $item->lowongan_id)); ?>">
                                                            <em class="icon ni ni-eye"></em><span>Lihat Detail</span>
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\raki\Documents\raki4\pbl\raki\Internify\resources\views/mahasiswa/lowongan/index.blade.php ENDPATH**/ ?>