<?php $__env->startSection('action'); ?>
    <li class="nk-block-tools-opt">
        <a href="#" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#tambahAlternatifModal">
            <em class="icon ni ni-plus"></em>
            <span>Tambah alternatif</span>
        </a>
    </li>
    <li class="nk-block-tools-opt">
        <a href="<?php echo e(route('spk.index')); ?>" class="btn btn-info" target="_blank">
            <em class="icon ni ni-eye"></em>
            <span>Hasil Rekomendasi</span>
        </a>
    </li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card card-bordered card-preview">
        <div class="card-inner">
            <table class="datatable-init-export nowrap nk-tb-list nk-tb-ulist" data-auto-responsive="false">
                <thead>
                    <tr class="nk-tb-item nk-tb-head">
                        <th class="nk-tb-col tb-col-md export-col"><span class="sub-text">Lowongan</span></th>
                        <?php $__currentLoopData = $kriterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th class="nk-tb-col export-col"><span class="sub-text"><?php echo e($k->nama); ?></span></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <th class="nk-tb-col nk-tb-col-tools text-end"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $alternatifs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="nk-tb-col tb-col-md">
                                <span><?php echo e($alt->lowongan->title); ?></span>
                            </td>
                            <?php $__currentLoopData = $kriterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kriteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $nilai = $alt->nilaiAlternatif->firstWhere('kriteria_id', $kriteria->kriteria_id);
                                ?>
                                <td>
                                    <?php if($nilai && $nilai->nilai > 0): ?>
                                        <?php echo e($nilai->kriteria->skorKriterias
                                                ->firstWhere('nilai', $nilai->nilai)?->parameter ?? 'Parameter tidak ditemukan'); ?>

                                    <?php else: ?>
                                        <span class="text-danger">Belum ada nilai</span>
                                    <?php endif; ?>
                                </td>
                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td class="nk-tb-col nk-tb-col-tools">
                                <ul class="nk-tb-actions gx-1">
                                    <li>
                                        <div class="drodown">
                                            <a href="#" class="dropdown-toggle btn btn-icon btn-trigger"
                                                data-bs-toggle="dropdown">
                                                <em class="icon ni ni-more-h"></em>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-end">
                                                <ul class="link-list-opt no-bdr">
                                                    <li>
                                                        <a href="#" class="btn-input-nilai"
                                                            data-id="<?php echo e($alt->alternatif_id); ?>">
                                                            <em class="icon ni ni-edit-alt"></em><span>Input Nilai</span>
                                                        </a>
                                                    </li>

                                                    <li class="divider"></li>
                                                    <li>
                                                        <form action="<?php echo e(route('alternatif.destroy', $alt->alternatif_id)); ?>" method="POST" onsubmit="return confirm('Yakin ingin menghapus alternatif ini?')" style="display:inline;">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit" class="dropdown-item">
                                                                <em class="icon ni ni-trash"></em><span>Hapus</span>
                                                            </button>
                                                        </form>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="modal fade" id="tambahAlternatifModal" tabindex="-1" aria-labelledby="tambahAlternatifModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered"> <!-- ✅ modal-sm + centered -->
            <div class="modal-content">
            </div>
        </div>
    </div>
    <div class="modal fade" id="modalInputNilai" tabindex="-1" aria-labelledby="modalInputNilaiLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <!-- Konten form akan dimuat via AJAX -->
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready(function() {
            $('#tambahAlternatifModal').on('show.bs.modal', function() {
                let modal = $(this);
                let modalContent = modal.find('.modal-content');

                // Load konten dari route
                $.ajax({
                    url: "<?php echo e(route('alternatif.create')); ?>",
                    type: 'GET',
                    success: function(response) {
                        modalContent.html(response);
                    },
                    error: function() {
                        modalContent.html(
                            '<div class="modal-body text-center text-danger p-4">Gagal memuat data.</div>'
                        );
                    }
                });
            });
        });
    </script>
    <script>
        $(document).ready(function() {
            $('.btn-input-nilai').on('click', function(e) {
                e.preventDefault();
                let alternatifId = $(this).data('id');
                let modal = $('#modalInputNilai');
                let modalContent = modal.find('.modal-content');

                $.ajax({
                    url: "/mahasiswa/alternatif/nilai/" + alternatifId,
                    method: 'GET',
                    success: function(response) {
                        modalContent.html(response);
                        modal.modal('show');
                    },
                    error: function() {
                        modalContent.html(
                            '<div class="modal-body text-center text-danger p-4">Gagal memuat form nilai.</div>'
                        );
                        modal.modal('show');
                    }
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\raki\Documents\raki4\pbl\raki\Internify\resources\views/mahasiswa/alternatif/index.blade.php ENDPATH**/ ?>