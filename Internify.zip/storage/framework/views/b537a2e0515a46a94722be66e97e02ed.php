<?php $__env->startSection('content'); ?>
    <div class="container mt-4">

        
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Detail Lowongan Magang</h5>
            </div>
            <div class="card-body">
                <table class="table table-bordered table-hover">
                    <tr>
                        <th style="width: 200px;">ID</th>
                        <td><?php echo e($logang->lowongan_id); ?></td>
                    </tr>
                    <tr>
                        <th>Nama Perusahaan</th>
                        <td><?php echo e($logang->company->user->name); ?></td>
                    </tr>
                    <tr>
                        <th>Judul Magang</th>
                        <td><?php echo e($logang->title); ?></td>
                    </tr>
                    <?php if($logang->benefits->count()): ?>
                        <tr class="list list-sm">
                            <?php $__currentLoopData = $logang->benefits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $benefit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th>BENEFIT</th>
                                <TD><?php echo e($benefit->name); ?></TD>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    <?php else: ?>
                        <p class="text-soft">Tidak ada benefit terdaftar.</p>
                    <?php endif; ?>
                    <tr>
                        <th>Deskripsi</th>
                        <td><?php echo $logang->description; ?></td>
                    </tr>
                    <tr>
                        <th>Periode Awal</th>
                        <td><?php echo e($logang->period->start_date); ?></td>
                    </tr>
                    <tr>
                        <th>Periode Akhir</th>
                        <td><?php echo e($logang->period->end_date); ?></td>
                    </tr>
                    <tr>
                        <th>Kriteria</th>
                        <td><?php echo $logang->requirements; ?></td>
                    </tr>
                </table>
            </div>
        </div>

        
        <div class="mt-3 d-flex">
            <?php if(Auth::user()->level_id == 1): ?>
                <a href="<?php echo e(route('lowongan-magang.index')); ?>" class="btn btn-secondary">Kembali</a>
            <?php elseif(Auth::user()->level_id == 2): ?>
                <a href="<?php echo e(route('lowongan-magang.indexMhs')); ?>" class="btn btn-secondary">Kembali</a>
            <?php endif; ?>

            <?php if(Auth::user()->level_id == 2): ?>
                <?php
                    $lamaran = Auth::user()
                        ->mahasiswa->applications->where('lowongan_id', $logang->lowongan_id)
                        ->first(); // Ambil lamaran mahasiswa untuk lowongan ini
                ?>

                <?php if(!$lamaran): ?>
                    <form action="<?php echo e(route('pengajuan-magang.storeMhs')); ?>" method="POST" class="ms-2"
                        onsubmit="return confirm('Yakin ingin melamar lowongan ini?')">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="lowongan_id" value="<?php echo e($logang->lowongan_id); ?>">
                        <input type="hidden" name="status" value="Pending">
                        <button type="submit" class="btn btn-primary">Lamar</button>
                    </form>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\raki\Documents\raki4\pbl\raki\Internify\resources\views/admin/lowonganMagang/show.blade.php ENDPATH**/ ?>