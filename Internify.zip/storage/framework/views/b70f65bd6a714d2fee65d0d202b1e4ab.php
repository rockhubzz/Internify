<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <div class="card card-bordered card-preview">
        <div class="card-inner table-responsive">
            <table class="datatable-init-export nowrap nk-tb-list nk-tb-ulist" data-auto-responsive="false">
                <thead>
                    <tr class="nk-tb-item nk-tb-head">
                        <th class="nk-tb-col"><span class="sub-text">No</span></th>
                        <th class="nk-tb-col"><span class="sub-text">Mahasiswa</span></th>
                        
                        <th class="nk-tb-col"><span class="sub-text">Isi Laporan</span></th>
                        <th class="nk-tb-col"><span class="sub-text">Tanggal</span></th>
                        <th class="nk-tb-col"><span class="sub-text">Status</span></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="nk-tb-item">
                            <td class="nk-tb-col">
                                <span><?php echo e($loop->iteration); ?></span>
                            </td>
                            <td class="nk-tb-col">
                                <span><?php echo e($log->mahasiswa->user->name ?? '-'); ?></span>
                            </td>
                            
                            <td class="nk-tb-col">
                                <span><?php echo e(Str::limit($log->report_text, 50)); ?></span>
                            </td>
                            <td class="nk-tb-col">
                                <span><?php echo e($log->created_at->format('d M Y')); ?></span>
                            </td>
                            <td class="nk-tb-col nk-tb-col-tools">
                                <?php if($log->verif_company === 'Disetujui'): ?>
                                    <span>Verified</span>
                                <?php elseif($log->verif_company === 'Ditolak'): ?>
                                    <span>Ditolak</span>
                                <?php else: ?>
                                <ul class="nk-tb-actions gx-1">
                                    <li>
                                        <div class="drodown">
                                            <a href="#" class="dropdown-toggle btn btn-icon btn-trigger"
                                                data-bs-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                            <div class="dropdown-menu dropdown-menu-end">
                                                <ul class="link-list-opt no-bdr">
                                                    <li><a href="<?php echo e(route('company.verifikasi.show', $log->log_id)); ?>"><em class="icon ni ni-eye"></em><span>Lihat Detail</span></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\raki\Documents\raki4\pbl\raki\Internify\resources\views/company/verifikasi.blade.php ENDPATH**/ ?>