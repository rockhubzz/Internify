<form id="formInputNilai" method="POST" action="<?php echo e(route('nilai.store', $alternatif->alternatif_id)); ?>">
    <?php echo csrf_field(); ?>

    <div class="modal-header">
        <h5 class="modal-title">Input Nilai untuk: <?php echo e($alternatif->lowongan->title); ?></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
    </div>

    <div class="modal-body">
        <?php $__currentLoopData = $kriterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kriteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="mb-3">
                <label class="form-label"><?php echo e($kriteria->nama); ?></label>
                <select name="nilai[<?php echo e($kriteria->kriteria_id); ?>]" class="form-select" required>
                    <option value="">-- Pilih --</option>
                    <?php $__currentLoopData = $skorKriterias[$kriteria->kriteria_id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($skor->nilai); ?>"><?php echo e($skor->parameter); ?> (<?php echo e($skor->nilai); ?>)</option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
        <button type="submit" class="btn btn-primary">Simpan Nilai</button>
    </div>
</form>
<script>
    // Pastikan handler ini di-trigger setelah modal dimuat
    $(document).on('submit', '#formInputNilai', function(e) {
        e.preventDefault();

        let form = $(this);
        let actionUrl = form.attr('action');
        let formData = form.serialize();

        $.ajax({
            url: actionUrl,
            method: 'POST',
            data: formData,
            success: function(response) {
                $('#modalInputNilai').modal('hide');
                form.trigger("reset");
                alert('Nilai berhasil disimpan.');
                location.reload(); // Bisa diganti fetch atau datatable redraw
            },
            error: function(xhr) {
                alert('Gagal menyimpan nilai. Cek kembali input.');
                console.error(xhr.responseText);
            }
        });
    });
</script>
<?php /**PATH C:\Users\raki\Documents\raki4\pbl\raki\Internify\resources\views/mahasiswa/nilai/create.blade.php ENDPATH**/ ?>