<?php use Illuminate\Support\Str; ?>
<?php $__env->startSection('action'); ?>
    <li class="nk-block-tools-opt">
        <a href="<?php echo e(route('laporan.create')); ?>" class="btn btn-primary">
            <em class="icon ni ni-plus"></em>
            <span>Tambah Laporan</span>
        </a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <div class="card card-bordered card-preview">
        <div class="card-inner">
            <table class="datatable-init-export nowrap nk-tb-list nk-tb-ulist" data-auto-responsive="false">
                <thead>
                    <tr class="nk-tb-item nk-tb-head">
                        <th class="nk-tb-col export-col"><span class="sub-text">Perusahaan</span></th>
                        <th class="nk-tb-col export-col"><span class="sub-text">Dosen Pembimbing</span></th>
                        <th class="nk-tb-col export-col"><span class="sub-text">Judul Laporan</span></th>
                        <th class="nk-tb-col export-col"><span class="sub-text">Tanggal</span></th>
                        <th class="nk-tb-col export-col d-none"><span class="sub-text">Verif Perusahaan</span></th>
                        <th class="nk-tb-col export-col d-none"><span class="sub-text">Verif Dosen</span></th>
                        <th class="nk-tb-col nk-tb-col-tools text-end"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="nk-tb-item">
                            <td class="nk-tb-col">
                                <span class="tb-amount"><em class="icon ni ni-building-fill"></em>
                                    <?php echo e($log->companies->user->name ?? '-'); ?>

                                </span>
                            </td>
                            <td class="nk-tb-col">
                                <span class="tb-amount"><?php echo e($log->dosen->user->name ?? '-'); ?></span>
                            </td>
                            <td class="nk-tb-col">
                                <span class="tb-amount"><?php echo e($log->report_title); ?></span>
                            </td>
                            <td class="nk-tb-col">
                                <span><?php echo e($log->created_at->format('d M Y')); ?></span>
                            </td>
                            <td class="nk-tb-col d-none">
                                <span><?php echo e($log->verif_company); ?></span>
                            </td>
                            <td class="nk-tb-col d-none">
                                <span><?php echo e($log->verif_dosen); ?></span>
                            </td>
                            <td class="nk-tb-col nk-tb-col-tools">
                                <ul class="nk-tb-actions gx-1">
                                    <li>
                                        <div class="drodown">
                                            <a href="#" class="dropdown-toggle btn btn-icon btn-trigger"
                                                data-bs-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                            <div class="dropdown-menu dropdown-menu-end">
                                                <ul class="link-list-opt no-bdr">
                                                    <li>
                                                        <a href="<?php echo e(route('laporan.show', $log->log_id)); ?>">
                                                            <em class="icon ni ni-eye"></em><span>Lihat Detail</span>
                                                        </a>
                                                    </li>
                                                    <?php if(auth()->user()->hasRole('Mahasiswa')): ?>
                                                        <li>
                                                            <a href="<?php echo e(route('laporan.edit', $log->log_id)); ?>">
                                                                <em class="icon ni ni-edit"></em><span>Edit</span>
                                                            </a>
                                                        </li>
                                                        <li class="divider"></li>
                                                        <li>
                                                            <form action="<?php echo e(route('laporan.destroy', $log->log_id)); ?>"
                                                                method="POST"
                                                                onsubmit="return confirm('Yakin ingin menghapus laporan ini?')">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>
                                                                <button type="submit" class="btn btn-link text-danger">
                                                                    <em class="icon ni ni-trash"></em><span>Hapus</span>
                                                                </button>
                                                            </form>
                                                        </li>
                                                    <?php endif; ?>
                                                </ul>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\raki\Documents\raki4\pbl\raki\Internify\resources\views/mahasiswa/laporan/index.blade.php ENDPATH**/ ?>