<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <div class="card card-bordered card-preview">
        <div class="card-inner table-responsive">
            <table class="datatable-init-export nowrap nk-tb-list nk-tb-ulist" data-auto-responsive="false">
                <thead>
                    <tr class="nk-tb-item nk-tb-head">
                        <th class="nk-tb-col">
                            <span class="sub-text">No</span>
                        </th>
                        <th class="nk-tb-col"><span class="sub-text">Mahasiswa</span></th>
                        
                        <th class="nk-tb-col"><span class="sub-text">Judul Laporan</span></th>
                        <th class="nk-tb-col"><span class="sub-text">Tanggal</span></th>
                        <th class="nk-tb-col"><span class="sub-text">Status</span></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="nk-tb-item">
                            <td class="nk-tb-col">
                                <span><?php echo e($loop->iteration); ?></span>
                            </td>
                            <td class="nk-tb-col">
                                <span><?php echo e($log->mahasiswa->user->name ?? '-'); ?></span>
                            </td>
                            
                            <td class="nk-tb-col">
                                <span><?php echo e(Str::limit(Strip_tags($log->report_title, 50))); ?></span>
                            </td>
                            <td class="nk-tb-col">
                                <span><?php echo e($log->created_at->format('d M Y')); ?></span>
                            </td>
                            <td class="nk-tb-col nk-tb-col-tools" style="white-space: nowrap; max-width: 150px; word-wrap: break-word;">
                                <?php
                                    $sudahDievaluasi = \App\Models\EvaluasiMagang::where('mahasiswa_id', $log->mahasiswa_id)
                                                        ->where('log_id', $log->log_id)
                                                        ->exists();
                                ?>
                                <?php if($sudahDievaluasi): ?>
                                    <span>Sudah dievaluasi</span>

                                <?php elseif($log->verif_company === 'Disetujui'): ?>
                                    
                                    <a href="<?php echo e(route('dosen.verifikasi.show', $log->log_id)); ?>" class="btn btn-sm btn-primary">
                                        Detail
                                    </a>
                               
                                <?php elseif($log->verif_company === 'Ditolak'): ?>
                                    <span>Ditolak</span>
                                
                                <?php else: ?>
                                    <span>Pending</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\raki\Documents\raki4\vsga\prod\Internify\resources\views/dosen/verifikasi.blade.php ENDPATH**/ ?>