<?php $__env->startSection('action'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <div class="card card-bordered card-preview">
        <div class="card-inner">
            <table class="datatable-init-export nowrap nk-tb-list nk-tb-ulist" data-auto-responsive="false">
                <thead>
                    <tr class="nk-tb-item nk-tb-head">
                        <th class="nk-tb-col export-col"><span class="sub-text">Mahasiswa</span></th>
                        <th class="nk-tb-col tb-col-mb export-col"><span class="sub-text">Lowongan</span></th>
                        <th class="nk-tb-col tb-col-mb export-col"><span class="sub-text">Perusahaan</span></th>
                        <th class="nk-tb-col tb-col-mb export-col"><span class="sub-text">Status</span></th>
                        <th class="nk-tb-col nk-tb-col-tools text-end"><span class="sub-text">Aksi</span></th>
                        <th class="nk-tb-col nk-tb-col-tools text-end"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $magangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $magang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="nk-tb-item">
                            <td class="nk-tb-col">
                                <div class="user-card">
                                    <div class="user-avatar bg-teal-dim d-none d-sm-flex">
                                        <?php if($magang->mahasiswas->user->image): ?>
                                            <img src="<?php echo e(Storage::url('images/users/' . $magang->mahasiswas->user->image)); ?>"
                                                alt="<?php echo e($magang->mahasiswas->user->name); ?>">
                                        <?php else: ?>
                                            <span><?php echo e(strtoupper(substr($magang->mahasiswas->user->name, 0, 2))); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="user-info">
                                        <span class="tb-lead"><?php echo e($magang->mahasiswas->user->name); ?><span
                                                class="dot dot-success d-md-none ms-1"></span></span>
                                        <span><?php echo e($magang->mahasiswas->user->email); ?></span>
                                    </div>
                                </div>
                            </td>
                            <td class="nk-tb-col tb-col-mb">
                                <span><?php echo e($magang->lowongans->title); ?></span>
                            </td>
                            <td class="nk-tb-col tb-col-mb">
                                <span><?php echo e($magang->lowongans->company->user->name); ?></span>
                            </td>
                            <td class="nk-tb-col tb-col-mb">
                                <?php if($magang->status === 'Disetujui'): ?>
                                    <span class="tb-status text-success"><?php echo e($magang->status); ?></span>
                                <?php elseif($magang->status === 'Ditolak'): ?>
                                    <span class="tb-status text-danger"><?php echo e($magang->status); ?></span>
                                <?php else: ?>
                                    <span class="tb-status text-warning"><?php echo e($magang->status); ?></span>
                                <?php endif; ?>
                            </td>
                            <td class="nk-tb-col nk-tb-col-tools">
                                <ul class="nk-tb-actions gx-1">
                                    <li>
                                        <div class="drodown">
                                            <a href="#" class="dropdown-toggle btn btn-icon btn-trigger"
                                                data-bs-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                            <div class="dropdown-menu dropdown-menu-end">
                                                <ul class="link-list-opt no-bdr">
                                                    <li>
                                                        <a href="#"><em class="icon ni ni-focus"></em><span>Quick
                                                                View</span></a>
                                                    </li>
                                                    <li>
                                                        <a href="#"><em class="icon ni ni-eye"></em><span>View
                                                                Details</span></a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </li>
                                </ul>

                                <?php if($magang->status === 'Disetujui' || $magang->status === 'Ditolak'): ?>
                                    <span>Reviewed</span>
                                <?php else: ?>
                                    <form action="<?php echo e(route('pengajuan-magang.update', $magang->magang_id)); ?>"
                                        method="POST" style="display: inline;"
                                        onsubmit="return confirm('Apakah anda yakin menyetujui lamaran ini?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <input type="hidden" name="status" value="Disetujui">
                                        <button type="submit" class="btn btn-link p-0 m-0 align-baseline text-light"
                                            style="background: rgb(32, 155, 32)">
                                            <span style="padding:5px;">Setuju</span></button>
                                    </form>

                                    <form action="<?php echo e(route('pengajuan-magang.update', $magang->magang_id)); ?>"
                                        method="POST" style="display: inline;"
                                        onsubmit="return confirm('Apakah anda yakin menolak lamaran ini?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <input type="hidden" name="status" value="Ditolak">
                                        <button type="submit" class="btn btn-link p-0 m-0 align-baseline text-light"
                                            style="background: red;">
                                            <span style="padding: 5px;">Tolak</span>
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </td>
                            <td class="nk-tb-col nk-tb-col-tools">
                                <ul class="nk-tb-actions gx-1">
                                    <li>
                                        <div class="drodown">
                                            <a href="#" class="dropdown-toggle btn btn-icon btn-trigger"
                                                data-bs-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                            <div class="dropdown-menu dropdown-menu-end">
                                                <ul class="link-list-opt no-bdr">
                                                    <li><a href="<?php echo e(route('pengajuan-magang.show', $magang->magang_id)); ?>"><em
                                                                class="icon ni ni-eye"></em><span>Lihat
                                                                Detail</span></a></li>

                                                    <li class="divider"></li>

                                                    <li><a
                                                            href="<?php echo e(route('pengajuan-magang.destroy', $magang->magang_id)); ?>"><em
                                                                class="icon ni ni-trash"></em><span>Hapus
                                                                Lamaran</span></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\raki\Documents\raki4\pbl\raki\Internify\resources\views/admin/pengajuanMagang/index.blade.php ENDPATH**/ ?>