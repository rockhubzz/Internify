<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>
    <div class="nk-block">
        <div class="data-head">
            <h6 class="overline-title">Progress Pengajuan</h6>
        </div>
        <div class="row g-gs">
            <div class="col-sm-6 col-lg-4 col-xxl-3">
                <div class="card card-bordered">
                    <div class="card-inner">
                        <div class="project">
                            <div class="project-head">
                                <div class="project-info">
                                    <h6 class="title"><?php echo e($status); ?></h6>
                                    <span class="sub-text">Internify</span>
                                </div>
                            </div>
                            <hr>
                            <?php if($magang): ?>
                                <p class="mb-1 text-muted">Tempat Magang:</p>
                                <p class="fw-semibold"><?php echo e($magang->lowongans->company->user->name); ?></p>

                                <p class="mb-1 text-muted">Judul Magang:</p>
                                <p class="fw-semibold"><?php echo e($magang->lowongans->title); ?></p>

                                <p class="mb-1 text-muted">Periode:</p>
                                <p>
                                    <span class="fw-semibold">
                                        <?php echo e(\Carbon\Carbon::parse($magang->lowongans->period->start_date)->translatedFormat('d M Y')); ?>

                                        -
                                        <?php echo e(\Carbon\Carbon::parse($magang->lowongans->period->end_date)->translatedFormat('d M Y')); ?>

                                    </span>
                                </p>
                            <?php else: ?>
                                <p class="project-details">Anda belum memiliki magang aktif.</p>
                                <p class="project-details">Silakan buka menu Lowongan Magang untuk melamar.</p>
                                <div class="text-end">
                                    <a href="<?php echo e(route('list.lowongan')); ?>" class="btn btn-md btn-primary">Cari Lowongan</a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-lg-4 col-xxl-3">
                <div class="card card-bordered">
                    <div class="card-inner">
                        <div class="project">
                            <div class="project-head">
                                <a href="html/apps-kanban.html" class="project-title">
                                    <div class="user-avatar sq bg-purple">
                                        <em class="ni ni-file-check-fill"></em>
                                    </div>
                                    <div class="project-info">
                                        <h6 class="title">Progress Magang</h6>
                                        <span class="sub-text">Persentase saat ini</span>
                                    </div>
                                </a>
                            </div>
                            <div class="project-progress">
                                <div class="project-progress-details">
                                    <div class="project-progress-task"><em class="icon ni ni-check-round-cut"></em><span>4
                                            Tasks</span></div>
                                    <div class="project-progress-percent"><?php echo e($progressPercent); ?>%</div>
                                </div>
                                <div class="progress progress-pill progress-md bg-light">
                                    <div class="progress-bar" data-progress="<?php echo e($progressPercent); ?>"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="nk-block">
        <div class="data-head">
            <h6 class="overline-title">Formulir</h6>
        </div>
        <div class="row g-gs">
            <!-- Pendataan -->
            <div class="col-sm-6 col-lg-4 col-xxl-3">
                <div class="card card-bordered">
                    <div class="card-inner">
                        <div class="project">
                            <div class="project-head">
                                <a href="#" class="project-title">
                                    <div class="user-avatar sq bg-purple">
                                        <em class="ni ni-file-check-fill"></em>
                                    </div>
                                    <div class="project-info">
                                        <h6 class="title">Pendataan</h6>
                                        <span class="sub-text">Profil Akademik</span>
                                    </div>
                                </a>
                            </div>
                            <div class="project-details">
                                <p>Pada tahap ini Mahasiswa diwajibkan mengunggah dan melengkapi data profil akademik
                                    mahasiswa untuk
                                    keperluan administrasi magang.</p>
                            </div>
                            <div class="divider"></div>
                            <div class="project-meta d-flex align-items-center justify-content-between">
                                <a href="<?php echo e(route('profil-akademik.index')); ?>" class="btn btn-md btn-primary">Lihat</a>

                                <?php if($isProfilLengkap): ?>
                                    <div class="d-flex align-items-center ms-2">
                                        <em class="ni ni-file-check text-success fs-4 me-1"></em>
                                        <small class="text-success fw-bold">Valid</small>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Pengajuan -->
            <div class="col-sm-6 col-lg-4 col-xxl-3">
                <div class="card card-bordered">
                    <div class="card-inner">
                        <div class="project">
                            <div class="project-head">
                                <a href="#" class="project-title"
                                    onclick="<?php echo e(!$isProfilLengkap ? 'event.preventDefault();' : ''); ?>">
                                    <div class="user-avatar sq bg-purple <?php echo e(!$isProfilLengkap ? 'opacity-50' : ''); ?>">
                                        <em class="ni ni-file-check-fill"></em>
                                    </div>
                                    <div class="project-info">
                                        <h6 class="title mb-0">Pengajuan</h6>
                                        <span class="sub-text">Bimbingan</span>
                                    </div>
                                </a>
                            </div>
                            <div class="project-details">
                                <p>
                                    Pada tahap ini Mahasiswa diwajibkan untuk mengunggah pengajuan dan persetujuan
                                    pembimbing magang
                                    dari dosen atau pihak kampus.
                                </p>
                            </div>
                            <div class="divider"></div>
                            <div class="project-meta">
                                <a href="<?php echo e($isProfilLengkap ? route('bimbingan.create') : '#'); ?>"
                                    class="btn btn-md btn-primary <?php echo e(!$isProfilLengkap ? 'disabled' : ''); ?>"
                                    <?php echo e(!$isProfilLengkap ? 'onclick=event.preventDefault();' : ''); ?>>
                                    Lihat
                                </a>
                                <?php if($bimbinganDisetujui): ?>
                                    <div class="d-flex align-items-center ms-2">
                                        <em class="ni ni-file-check text-success fs-4 me-1"></em>
                                        <small class="text-success fw-bold">Bimbingan Disetujui</small>
                                    </div>
                                <?php endif; ?>
                                <?php if(!$isProfilLengkap): ?>
                                    <small class="text-danger d-block mt-1">Lengkapi profil akademik terlebih
                                        dahulu.</small>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Pelaksanaan -->
            <div class="col-sm-6 col-lg-4 col-xxl-3">
                <div class="card card-bordered">
                    <div class="card-inner">
                        <div class="project">
                            <div class="project-head">
                                <a href="#" class="project-title">
                                    <div
                                        class="user-avatar sq bg-purple <?php echo e(!$bimbinganDisetujui ? 'opacity-50 pointer-events-none' : ''); ?>">
                                        <em class="ni ni-file-check-fill"></em>
                                    </div>
                                    <div class="project-info">
                                        <div class="d-flex justify-content-between align-items-start">
                                            <h6 class="title mb-0">Pelaksanaan</h6>
                                            <?php if($periodeMagang): ?>
                                                <span class="badge bg-light text-dark small ms-2">Sisa:
                                                    <?php echo e($sisaWaktuMagang); ?></span>
                                            <?php else: ?>
                                                <span class="badge bg-light text-muted small ms-2">Periode tidak
                                                    tersedia</span>
                                            <?php endif; ?>
                                        </div>
                                        <span class="sub-text">Magang</span>
                                    </div>
                                </a>
                            </div>

                            <div class="project-details">
                                <p>
                                    Pada tahap ini Mahasiswa diwajibkan untuk mengunggah dokumen, seperti laporan untuk
                                    monitoring kegiatan magang mahasiswa selama masa penempatan di perusahaan.
                                </p>
                            </div>

                            <div class="divider"></div>
                            <div class="project-meta">
                                <a href="<?php echo e(route('laporan')); ?>"
                                    class="btn btn-md btn-primary <?php echo e(!$bimbinganDisetujui ? 'disabled opacity-50 pointer-events-none' : ''); ?>">
                                    Lihat
                                </a>
                                <?php if($isAkhirPeriode): ?>
                                    <div class="d-flex align-items-center ms-2">
                                        <em class="ni ni-file-check text-success fs-4 me-1"></em>
                                        <small class="text-success fw-bold">Magang berakhir</small>
                                    </div>
                                <?php endif; ?>
                                <?php if(!$bimbinganDisetujui): ?>
                                    <small class="text-danger d-block mt-1">Ajukan bimbingan terlebih dahulu.</small>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Tahap Akhir -->
            <div class="col-sm-6 col-lg-4 col-xxl-3">
                <div class="card card-bordered">
                    <div class="card-inner">
                        <div class="project">
                            <div class="project-head">
                                <a href="#" class="project-title">
                                    
                                    <div
                                        class="user-avatar sq bg-purple <?php echo e(!$isAkhirPeriode ? 'opacity-50 pointer-events-none' : ''); ?>">
                                        <em class="ni ni-file-check-fill"></em>
                                    </div>
                                    <div class="project-info">
                                        <h6 class="title">Tahap Akhir</h6>
                                        <span class="sub-text">Magang</span>
                                    </div>
                                </a>
                            </div>

                            <div class="project-details">
                                <p>
                                    Pada tahap ini Mahasiswa diwajibkan untuk mengunggah dokumen laporan akhir magang dan
                                    proses evaluasi dari dosen pembimbing.
                                </p>
                            </div>

                            <div class="divider"></div>
                            <div class="project-meta">
                                
                                <a href="#"
                                    class="btn btn-md btn-primary <?php echo e(!$isAkhirPeriode ? 'disabled opacity-50 pointer-events-none' : ''); ?>"
                                    <?php echo e(!$isAkhirPeriode ? 'onclick=event.preventDefault();' : ''); ?>>
                                    Lihat
                                </a>
                                <?php if(!$isAkhirPeriode): ?>
                                    <small class="text-danger d-block mt-1">Tersedia setelah periode magang
                                        selesai.</small>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\raki\Documents\raki4\pbl\raki\Internify\resources\views/mahasiswa/dashboard/mahasiswa.blade.php ENDPATH**/ ?>