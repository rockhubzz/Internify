<footer class="footer bg-dark is-dark">
    <div class="container">
        <div class="row g-gs justify-content-between py-4 py-md-6">
            <div class="col-lg-4 col-md-6">
                <div class="widget widget-about mt-n2">

                    <img class="logo-light logo-img" src="<?php echo e(asset('assets/home/images/logo.png')); ?>"
                        srcset="<?php echo e(asset('assets/home/images/logo2x.png 2x')); ?>" alt="logo">
                    <img class="logo-dark logo-img" src="<?php echo e(asset('assets/home/images/logo-dark.png')); ?>"
                        srcset="<?php echo e(asset('assets/home/images/logo-dark2x.png 2x')); ?>" alt="logo-dark">
                    </a>
                    <p class="mt-3">Solusi manajemen magang digital untuk mahasiswa, institusi, dan mitra industri.</p>
                </div>
            </div>
            <!-- .col -->
            
            <!-- .col -->
        </div>
        <!-- .row -->
        <hr class="hr border-light mb-0 mt-n1">
        <div class="row g-3 align-items-center justify-content-md-between py-4">
            <div class="col-md-8">
                <div>
                    Copyright &copy;2025 Internify. All rights reserved <a class="text-base fw-bold"
                        href="#">Kelompok 3</a>
                </div>
            </div>
            <!-- .col -->
            <div class="col-md-4 d-flex justify-content-md-end">
                <ul class="social">
                    <li>
                        <a href="https://github.com/RifkiArdiy/Internify">
                            <em class="icon ni ni-github"></em>
                        </a>
                    </li>
                    
                </ul>
                <!-- .footer-icon -->
            </div>
            <!-- .col -->
        </div>
        <!-- .row -->
    </div>
    <!-- .container -->
</footer>
<?php /**PATH C:\Users\raki\Documents\raki4\vsga\prod\Internify\resources\views/listing/footer.blade.php ENDPATH**/ ?>