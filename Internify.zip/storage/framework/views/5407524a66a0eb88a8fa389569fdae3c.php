<?php $__env->startSection('content'); ?>
    <div class="card card-bordered card-preview">
        <div class="card-inner">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <form method="POST" action="<?php echo e(route('lowonganMagang.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="row g-4">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label">Perusahaan</label>
                            <select name="company" id="company" class="form-control" required>
                                <option value="">- Pilih Perusahaan -</option>
                                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->company_id); ?>"><?php echo e($item->user->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label">Periode Magang</label>
                            <select name="period" id="period" class="form-control" required>
                                <option value="">- Pilih Periode Magang -</option>
                                <?php $__currentLoopData = $periode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->period_id); ?>"><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label">Judul: <span class="text-danger">*</label>
                            <input type="text" class="form-control" name="title" id="title"
                                value="<?php echo e(old('title')); ?>" placeholder="Masukkan Judul Lowongan" required>
                        </div>
                    </div>

                    <div class="col-12">
                        <div class="form-group">
                            <label class="form-label">Deskripsi: <span class="text-danger">*</label>
                            <!-- Editor tampil di sini -->
                            <div id="quill-editor" style="height: 200px;"><?php echo old('description'); ?></div>
                            <!-- Data yang akan dikirim ke controller -->
                            <input type="hidden" name="description" id="description">
                        </div>
                    </div>
                    <!-- Requirements (dengan Quill) -->
                    <div class="col-12">
                        <div class="form-group">
                            <label class="form-label">Kriteria: <span class="text-danger">*</label>
                            <!-- Quill Editor -->
                            <div id="quill-requirements" style="height: 200px;"><?php echo old('requirements'); ?></div>
                            <!-- Hidden input to store Quill content -->
                            <input type="hidden" name="requirements" id="requirements">
                        </div>
                    </div>


                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label">Lokasi</label>
                            <input type="text" name="location" class="form-control" placeholder="Masukkan Lokasi Magang"
                                value="<?php echo e(old('location')); ?>" required>
                        </div>
                    </div>

                    <div class="col-12">
                        <button type="submit" class="btn btn-primary mt-3">Simpan</button>
                        <a href="<?php echo e(route('lowonganMagang.index')); ?>" class="btn btn-secondary mt-3">Kembali</a>
                    </div>
                </div>
            </form>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
    <link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
    <script src="https://cdn.quilljs.com/1.3.6/quill.js"></script>

    <script>
        // Inisialisasi Quill untuk Deskripsi
        const quillDescription = new Quill('#quill-editor', {
            theme: 'snow',
            placeholder: 'Masukkan Deskripsi Lowongan',
            modules: {
                toolbar: [
                    ['bold', 'italic', 'underline', 'strike'],
                    [{
                        'list': 'ordered'
                    }, {
                        'list': 'bullet'
                    }],
                    ['clean']
                ]
            }
        });

        // Inisialisasi Quill untuk Kriteria
        const quillRequirements = new Quill('#quill-requirements', {
            theme: 'snow',
            placeholder: 'Masukkan Kriteria Magang',
            modules: {
                toolbar: [
                    ['bold', 'italic', 'underline', 'strike'],
                    [{
                        'list': 'ordered'
                    }, {
                        'list': 'bullet'
                    }],
                    ['clean']
                ]
            }
        });

        // Gabungkan onsubmit untuk dua input
        const form = document.querySelector('form');
        form.onsubmit = function() {
            document.querySelector('input[name=description]').value = quillDescription.root.innerHTML;
            document.querySelector('input[name=requirements]').value = quillRequirements.root.innerHTML;
        };
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\raki\Documents\raki4\pbl\raki\Internify\resources\views/admin/lowonganMagang/create.blade.php ENDPATH**/ ?>