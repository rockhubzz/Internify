<?php $__env->startSection('content'); ?>
    <div class="container mt-4">

        
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Detail Lowongan Magang</h5>
            </div>
            <div class="card-body">
                <table class="table table-bordered table-hover">
                    <tr>
                        <th style="width: 200px;">ID</th>
                        <td><?php echo e($logang->lowongan_id); ?></td>
                    </tr>
                    <tr>
                        <th>Nama Perusahaan</th>
                        <td><?php echo e($logang->company->user->name); ?></td>
                    </tr>
                    <tr>
                        <th>Judul Magang</th>
                        <td><?php echo e($logang->title); ?></td>
                    </tr>
                    <?php if($logang->benefits->count()): ?>
                        <tr class="list list-sm">
                            <?php $__currentLoopData = $logang->benefits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $benefit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th>BENEFIT</th>
                                <TD><?php echo e($benefit->name); ?></TD>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    <?php else: ?>
                        <p class="text-soft">Tidak ada benefit terdaftar.</p>
                    <?php endif; ?>
                    <tr>
                        <th>Deskripsi</th>
                        <td><?php echo $logang->description; ?></td>
                    </tr>
                    <tr>
                        <th>Periode Awal</th>
                        <td><?php echo e($logang->period->start_date); ?></td>
                    </tr>
                    <tr>
                        <th>Periode Akhir</th>
                        <td><?php echo e($logang->period->end_date); ?></td>
                    </tr>
                    <tr>
                        <th>Kriteria</th>
                        <td><?php echo $logang->requirements; ?></td>
                    </tr>
                </table>
            </div>
        </div>

        
        <div class="mt-3 d-flex">
            <a href="<?php echo e(route('companys-lowongan-magang.edit', $logang->lowongan_id)); ?>" class="btn btn-primary">Edit Lowongan</a>
        </div>

        <h4>Daftar Pelamar</h4>
        <?php $__currentLoopData = $mahasiswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href=""><?php echo e($item->user->name); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\raki\Documents\raki4\pbl\raki\Internify\resources\views/company/lowonganMagang/show.blade.php ENDPATH**/ ?>