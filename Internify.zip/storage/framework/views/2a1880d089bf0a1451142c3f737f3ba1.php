<?php $__env->startSection('action'); ?>
    <li class="nk-block-tools-opt">
        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-light">
            <em class="icon ni ni-arrow-left"></em>
            <span>Kembali</span>
        </a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card card-bordered">
        <div class="card-inner">
            <div class="nk-block-head nk-block-head-sm">
                <div class="nk-block-between g-3">
                    <div class="nk-block-head-content">
                        <h3 class="nk-block-title page-title">Users / <strong
                                class="text-primary small"><?php echo e($comp->user->name ?? 'N/A'); ?></strong></h3>
                        <div class="nk-block-des text-soft">
                            <ul class="list-inline">
                                <li>User ID: <span class="text-base"><?php echo e($comp->user_id ?? 'N/A'); ?></span></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div><!-- .nk-block-head -->
            <div class="nk-block">
                <div class="card card-bordered">
                    <div class="card-aside-wrap">
                        <div class="card-content">
                            <ul class="nav nav-tabs nav-tabs-mb-icon">
                                <li class="nav-item">
                                    <a class="nav-link active" href="#"><em
                                            class="icon ni ni-user-circle"></em><span>Personal</span></a>
                                </li>
                                <li class="nav-item nav-item-trigger d-xxl-none">
                                    <a href="#" class="toggle btn btn-icon btn-trigger" data-target="userAside"><em
                                            class="icon ni ni-user-list-fill"></em></a>
                                </li>
                            </ul><!-- .nav-tabs -->
                            <div class="card-inner">
                                <div class="nk-block">
                                    <div class="nk-block-head">
                                        <h5 class="title">Personal Information</h5>
                                        <p>Basic info, like your name and address, that you use on Nio Platform.</p>
                                    </div><!-- .nk-block-head -->
                                    <div class="profile-ud-list">
                                        <div class="profile-ud-item">
                                            <div class="profile-ud wider">
                                                <span class="profile-ud-label">Full Name</span>
                                                <span class="profile-ud-value"><?php echo e($comp->user->name); ?></span>
                                            </div>
                                        </div>
                                        <div class="profile-ud-item">
                                            <div class="profile-ud wider">
                                                <span class="profile-ud-label">Username</span>
                                                <span class="profile-ud-value"><?php echo e($comp->user->username ?? 'N/A'); ?></span>
                                            </div>
                                        </div>
                                        <div class="profile-ud-item">
                                            <div class="profile-ud wider">
                                                <span class="profile-ud-label">Email Address</span>
                                                <span class="profile-ud-value"><?php echo e($comp->user->email ?? 'N/A'); ?></span>
                                            </div>
                                        </div>
                                        <div class="profile-ud-item">
                                            <div class="profile-ud wider">
                                                <span class="profile-ud-label">Mobile Number</span>
                                                <span class="profile-ud-value"><?php echo e($comp->user->no_telp ?? 'N/A'); ?></span>
                                            </div>
                                        </div>
                                        <div class="profile-ud-item">
                                            <div class="profile-ud wider">
                                                <span class="profile-ud-label">Alamat</span>
                                                <span class="profile-ud-value"><?php echo e($comp->user->alamat ?? 'N/A'); ?></span>
                                            </div>
                                        </div>
                                        <div class="profile-ud-item">
                                            <div class="profile-ud wider">
                                                <span class="profile-ud-label">Joining Date</span>
                                                <span class="profile-ud-value"><?php echo e($comp->created_at); ?></span>
                                            </div>
                                        </div>
                                    </div><!-- .profile-ud-list -->
                                </div><!-- .nk-block -->
                                <div class="nk-block">
                                    <div class="nk-block-head nk-block-head-line">
                                        <h6 class="title overline-title text-base">Additional Information</h6>
                                    </div><!-- .nk-block-head -->
                                    <div class="nk-block-head">
                                        <div class="profile-ud-label mb-1">Tentang Perusahaan</div>
                                        <p class="profile-ud-value"><?php echo $comp->about_company; ?></p>
                                    </div>
                                </div><!-- .nk-block -->
                                <div class="nk-divider divider md"></div>
                            </div><!-- .card-inner -->
                        </div><!-- .card-content -->
                        
                    </div><!-- .card-aside-wrap -->
                </div><!-- .card -->
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\raki\Documents\raki4\pbl\raki\Internify\resources\views/admin/company/show.blade.php ENDPATH**/ ?>