<?php $__env->startSection('content'); ?>

    
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <div class="row">

        <div class="col-md-4">
            <div class="card text-white bg-primary mb-3">
                <div class="card-header">Mahasiswa Magang</div>
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($jumlahMahasiswaMagang); ?></h5>
                    <p class="card-text">Total mahasiswa yang sedang menjalani magang.</p>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card text-white bg-success mb-3">
                <div class="card-header">Dosen Pembimbing</div>
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($jumlahDosenPembimbing); ?></h5>
                    <p class="card-text">Jumlah dosen pembimbing yang terdaftar.</p>
                </div>
            </div>
        </div>

        <h6 class="mb-2">Rasio Mahasiswa Magang : Dosen</h6>
            <div class="progress mb-3" style="height: 30px; " >
                <div class="progress-bar bg-primary" role="progressbar"
                    style="width: <?php echo e(($jumlahMahasiswaMagang / ($jumlahMahasiswaMagang + $jumlahDosenPembimbing)) * 100); ?>%;"
                    aria-valuenow="<?php echo e($jumlahMahasiswaMagang); ?>" aria-valuemin="0" aria-valuemax="<?php echo e($jumlahMahasiswaMagang + $jumlahDosenPembimbing); ?>">
                    Mahasiswa (<?php echo e($jumlahMahasiswaMagang); ?>)
                </div>
                <div class="progress-bar bg-success" role="progressbar"
                    style="width: <?php echo e(($jumlahDosenPembimbing / ($jumlahMahasiswaMagang + $jumlahDosenPembimbing)) * 100); ?>%;"
                    aria-valuenow="<?php echo e($jumlahDosenPembimbing); ?>" aria-valuemin="0" aria-valuemax="<?php echo e($jumlahMahasiswaMagang + $jumlahDosenPembimbing); ?>">
                    Dosen (<?php echo e($jumlahDosenPembimbing); ?>)
                </div>
            </div>
    
    </div>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\raki\Documents\raki4\pbl\raki\Internify\resources\views/admin/monitoring/index.blade.php ENDPATH**/ ?>