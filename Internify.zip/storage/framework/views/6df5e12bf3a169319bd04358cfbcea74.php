<div class="nk-header nk-header-fixed is-light">
    <div class="container-fluid">
        <div class="nk-header-wrap">
            <div class="nk-menu-trigger d-xl-none ms-n1">
                <a href="#" class="nk-nav-toggle nk-quick-nav-icon" data-target="sidebarMenu">
                    <em class="icon ni ni-menu"></em>
                </a>
            </div>
            <div class="nk-header-brand d-xl-none">
                <a href="<?php echo e(route('welcome.index')); ?>" class="logo-link nk-sidebar-logo">
                    <img class="logo-light logo-img" src="<?php echo e(asset('assets/home/images/logo.png')); ?>"
                        srcset="<?php echo e(asset('assets/home/images/logo2x.png 2x')); ?>" alt="logo">
                    <img class="logo-dark logo-img" src="<?php echo e(asset('assets/home/images/logo-dark.png')); ?>"
                        srcset="<?php echo e(asset('assets/home/images/logo-dark2x.png 2x')); ?>" alt="logo-dark">
                </a>
            </div>
            <!-- .nk-header-brand -->
            <div class="nk-header-news d-none d-xl-block">
                <div class="nk-news-list">
                    <ul class="breadcrumb breadcrumb-arrow">
                        <?php if(Auth::user()->level->level_nama == 'Administrator'): ?>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                        <?php elseif(Auth::user()->level->level_nama == 'Mahasiswa'): ?>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('mahasiswa.dashboard')); ?>">Dashboard</a></li>
                        <?php elseif(Auth::user()->level->level_nama == 'Dosen'): ?>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('dosen.dashboard')); ?>">Dashboard</a></li>
                        <?php elseif(Auth::user()->level->level_nama == 'Company'): ?>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('company.dashboard')); ?>">Dashboard</a></li>
                        <?php endif; ?>
                        <?php if($breadcrumb->title !== 'Dashboard'): ?>
                            <li class="breadcrumb-item active"><?php echo e($breadcrumb->title); ?></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
            <!-- .nk-header-news -->
            <div class="nk-header-tools">
                <ul class="nk-quick-nav">
                    <!-- .dropdown -->
                    <li class="dropdown user-dropdown">
                        <a href="#" class="dropdown-toggle" data-bs-toggle="dropdown">
                            <div class="user-toggle">
                                <div class="user-avatar sm">
                                    <?php if(auth()->check() && auth()->user()->image): ?>
                                        <img src="<?php echo e(Storage::url('images/users/' . auth()->user()->image)); ?>"
                                            alt="<?php echo e(auth()->user()->name); ?>">
                                    <?php else: ?>
                                        <span>
                                            <?php echo e(strtoupper(collect(explode(' ', Auth::user()->name))->map(fn($word) => $word[0])->take(2)->implode(''))); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="user-info d-none d-md-block">
                                    <div class="user-status"><?php echo e(Auth::user()->level->level_nama ?? 'Guest'); ?></div>
                                    <div class="user-name dropdown-indicator"><?php echo e(Auth::user()->name ?? 'Guest'); ?>

                                    </div>
                                </div>
                            </div>
                        </a>
                        <div class="dropdown-menu dropdown-menu-md dropdown-menu-end dropdown-menu-s1">
                            <div class="dropdown-inner user-card-wrap bg-lighter d-none d-md-block">
                                <div class="user-card">
                                    <div class="user-avatar">
                                        <span>
                                            <?php if(auth()->check() && auth()->user()->image): ?>
                                                <img src="<?php echo e(Storage::url('images/users/' . auth()->user()->image)); ?>"
                                                    alt="<?php echo e(auth()->user()->name); ?>">
                                            <?php else: ?>
                                                <?php echo e(strtoupper(collect(explode(' ', Auth::user()->name))->map(fn($word) => $word[0])->take(2)->implode(''))); ?>

                                            <?php endif; ?>
                                        </span>
                                    </div>
                                    <div class="user-info">
                                        <span class="lead-text"><?php echo e(Auth::user()->name ?? 'Guest'); ?></span>
                                        <span class="sub-text"><?php echo e(Auth::user()->email ?? 'Guest'); ?></span>
                                    </div>
                                </div>
                            </div>
                            <div class="dropdown-inner">
                                <ul class="link-list">
                                    <?php if(Auth::user()->level->level_nama == 'Administrator'): ?>
                                        <li>
                                            <a href="<?php echo e(route('profile')); ?>">
                                                <em class="icon ni ni-user-alt"></em>
                                                <span>View Profile</span>
                                            </a>
                                        </li>
                                    <?php elseif(Auth::user()->level->level_nama == 'Mahasiswa'): ?>
                                        <li>
                                            <a href="<?php echo e(route('profile')); ?>">
                                                <em class="icon ni ni-user-alt"></em>
                                                <span>View Profile</span>
                                            </a>
                                        </li>
                                    <?php elseif(Auth::user()->level->level_nama == 'Dosen'): ?>
                                        <li>
                                            <a href="<?php echo e(route('profile')); ?>">
                                                <em class="icon ni ni-user-alt"></em>
                                                <span>View Profile</span>
                                            </a>
                                        </li>
                                    <?php elseif(Auth::user()->level->level_nama == 'Company'): ?>
                                        <li>
                                            <a href="<?php echo e(route('profile')); ?>">
                                                <em class="icon ni ni-user-alt"></em>
                                                <span>View Profile</span>
                                            </a>
                                        </li>
                                    <?php endif; ?>
                                    <li>
                                        <a class="dark-switch" href="#">
                                            <em class="icon ni ni-moon"></em>
                                            <span>Dark Mode</span>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            <div class="dropdown-inner">
                                <ul class="link-list">
                                    <li>
                                        <a href="<?php echo e(route('logout')); ?>">
                                            <em class="icon ni ni-signout"></em>
                                            <span>Sign out</span>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </li>
                    <!-- .dropdown -->
                    <li class="dropdown notification-dropdown me-n1">
                        <a href="#" class="dropdown-toggle nk-quick-nav-icon" data-bs-toggle="dropdown">
                            <div class="icon-status icon-status-info">
                                <em class="icon ni ni-bell"></em>
                            </div>
                        </a>
                        <div class="dropdown-menu dropdown-menu-xl dropdown-menu-end dropdown-menu-s1">
                            <div class="dropdown-head">
                                <span class="sub-title nk-dropdown-title">Notifications</span>
                            </div>
                            <div class="dropdown-body">
                                <div class="nk-notification">
                                    <?php if(Auth::user()->getRole() === 'Mahasiswa'): ?>
                                        <?php if($notif_magang_list->isEmpty()): ?>
                                            <div class="nk-notification-item">
                                                <div class="nk-notification-content">
                                                    <div class="nk-notification-text">
                                                        Belum ada notifikasi terbaru
                                                    </div>
                                                </div>
                                            </div>
                                        <?php else: ?>
                                            <?php $__currentLoopData = $notif_magang_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="nk-notification-item d-flex align-items-start mb-2">
                                                    <div class="nk-notification-icon me-3">
                                                        <?php if($notif['m_status'] === 'Ditolak'): ?>
                                                            <em class="icon icon-circle bg-danger-dim ni ni-cross"></em>
                                                        <?php elseif($notif['m_status'] === 'Disetujui'): ?>
                                                            <em class="icon icon-circle bg-success-dim ni ni-check"></em>
                                                        <?php elseif($notif['m_status'] === 'Pending'): ?>
                                                            <em class="icon icon-circle bg-warning-dim ni ni-clock"></em>
                                                        <?php else: ?>
                                                            <em class="icon icon-circle bg-secondary-dim ni ni-info"></em>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="nk-notification-content">
                                                        <div class="nk-notification-text">
                                                            Lamaran magang anda di <?php echo e($notif['m_company_name']); ?>

                                                            <?php if($notif['m_status'] !== 'Pending'): ?>
                                                                telah <?php echo e(strtolower($notif['m_status'])); ?>

                                                            <?php else: ?>
                                                                sedang diproses
                                                            <?php endif; ?>
                                                        </div>
                                                        <div class="nk-notification-time"><?php echo e($notif['m_time']); ?></div>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    <?php elseif(Auth::user()->getRole() === 'Company'): ?>
                                        <?php if($notif_pending_list->isEmpty()): ?>
                                            <div class="nk-notification-item">
                                                <div class="nk-notification-content">
                                                    <div class="nk-notification-text">
                                                        Belum ada notifikasi terbaru
                                                    </div>
                                                </div>
                                            </div>
                                        <?php else: ?>
                                            <?php $__currentLoopData = $notif_pending_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <div class="nk-notification-item d-flex align-items-start mb-2">
                                                    <div class="nk-notification-icon me-3">
                                                        <em class="icon icon-circle bg-warning-dim ni ni-clock"></em>
                                                    </div>
                                                    <div class="nk-notification-content">
                                                        <div class="nk-notification-text">
                                                            <?php echo e($item['c_mahasiswa_name']); ?> menunggu review magang di bagian
                                                            <?php echo e($item['c_lowongan_title']); ?>

                                                        </div>
                                                        <div class="nk-notification-time"><?php echo e($item['c_created_at']); ?></div>
                                                    </div>
                                                </div>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                                <!-- .nk-notification -->
                            </div>
                            <!-- .nk-dropdown-body -->
                            <div class="dropdown-foot center">
                                <a href="<?php echo e(route('notif')); ?>">View All</a>
                            </div>
                        </div>
                    </li>
                    <!-- .dropdown -->
                </ul>
                <!-- .nk-quick-nav -->
            </div>
            <!-- .nk-header-tools -->
        </div>
        <!-- .nk-header-wrap -->
    </div>
    <!-- .container-fliud -->
</div><?php /**PATH C:\Users\raki\Documents\raki4\vsga\prod\Internify\resources\views/layouts/header.blade.php ENDPATH**/ ?>