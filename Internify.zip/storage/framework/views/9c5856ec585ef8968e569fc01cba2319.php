<?php $__env->startSection('content'); ?>
    <div class="card card-bordered card-preview mb-4">
        <div class="card-inner">
            <h5 class="title mb-3">Lamaran yang Menunggu Review</h5>       
            <table class="datatable-init table nowrap">
                <thead>
                    <tr>
                        <th>Nama Mahasiswa</th>
                        <th>Judul Lowongan</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $unreviewedLamarans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->mahasiswas->user->name); ?></td>
                            <td><?php echo e($item->lowongans->title); ?></td>
                            <td>
                                <a href="<?php echo e(route('company.magangApplication.show', $item->magang_id)); ?>" class="btn btn-success btn-sm">
                                    Lihat Detail
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\raki\Documents\raki4\pbl\raki\Internify\resources\views/dashboard/company.blade.php ENDPATH**/ ?>