<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <div class="card card-bordered">
        <div class="card-aside-wrap">
            <div class="card-inner card-inner-lg">
                <div class="nk-block-head nk-block-head-lg">
                    <div class="nk-block-between">
                        <div class="nk-block-head-content">
                            <h4 class="nk-block-title">Biodata</h4>
                        </div>
                        <div class="nk-block-head-content align-self-start d-lg-none">
                            <a href="#" class="toggle btn btn-icon btn-trigger mt-n1" data-target="userAside"><em
                                    class="icon ni ni-menu-alt-r"></em></a>
                        </div>
                    </div>
                </div><!-- .nk-block-head -->
                <div class="nk-block">
                    <div class="nk-data data-list row gy-3 gx-4">
                        <div class="data-head">
                            <h6 class="overline-title">Profil Akademik</h6>
                        </div>
                        <div class="data-item">
                            <div class="data-col">
                                <span class="data-label">Bidang Keahlian</span>
                                <span class="data-value"><?php echo e($profilAkademik->bidang_keahlian); ?></span>
                            </div>
                            <div class="data-col data-col-end">
                                <a class="btn btn-sm btn-outline-primary"
                                    href="<?php echo e(asset('storage/profil-akademik/bidang_keahlian/' . $profilAkademik->bidang_keahlian)); ?>"
                                    download>
                                    Download
                                </a>
                            </div>
                        </div>
                        <div class="data-item">
                            <div class="data-col">
                                <span class="data-label">Sertifikasi</span>
                                <span class="data-value"><?php echo e($profilAkademik->sertifikasi); ?></span>
                            </div>
                            <div class="data-col data-col-end">
                                <a class="btn btn-sm btn-outline-primary"
                                    href="<?php echo e(asset('storage/profil-akademik/' . $profilAkademik->sertifikasi)); ?>" download>
                                    Download
                                </a>
                            </div>
                        </div>
                        <div class="data-item">
                            <div class="data-col">
                                <span class="data-label">Pengalaman</span>
                                <span class="data-value"><?php echo e($profilAkademik->pengalaman); ?></span>
                            </div>
                            <div class="data-col data-col-end">
                                <a class="btn btn-sm btn-outline-primary"
                                    href="<?php echo e(asset('storage/profil-akademik/pengalaman/' . $profilAkademik->pengalaman)); ?>"
                                    download>
                                    Download
                                </a>
                            </div>
                        </div>
                        <div class="data-item">
                            <div class="data-col">
                                <span class="data-label">Etika</span>
                                <span class="data-value"><?php echo e($profilAkademik->etika); ?></span>
                            </div>
                            <div class="data-col data-col-end">
                                <a class="btn btn-sm btn-outline-primary"
                                    href="<?php echo e(asset('storage/profil-akademik/etika/' . $profilAkademik->etika)); ?>" download>
                                    Download
                                </a>
                            </div>
                        </div>
                        <div class="data-item">
                            <div class="data-col">
                                <span class="data-label">IPK</span>
                                <span class="data-value"><?php echo e($profilAkademik->ipk); ?></span>
                            </div>
                            <div class="data-col data-col-end">
                                <a class="btn btn-sm btn-outline-primary"
                                    href="<?php echo e(asset('storage/profil-akademik/ipk/' . $profilAkademik->ipk)); ?>" download>
                                    Download
                                </a>
                            </div>
                        </div>
                        <div class="data-item">
                            <div class="data-col">
                                
                            </div>
                            <div class="data-col data-col-end">
                                <a href="<?php echo e(route('profil-akademik.edit')); ?>" class="btn btn-secondary">Edit Profil
                                    Akademik</a>
                            </div>
                        </div>
                    </div><!-- .data-list -->
                </div><!-- .nk-block -->
            </div>
            <div class="card-aside card-aside-left user-aside toggle-slide toggle-slide-left toggle-break-lg"
                data-toggle-body="true" data-content="userAside" data-toggle-screen="lg" data-toggle-overlay="true">
                <div class="card-inner-group" data-simplebar>
                    <div class="card-inner">
                        <div class="user-card">
                            <div class="user-avatar bg-primary">
                                <?php if(auth()->check() && auth()->user()->image): ?>
                                    <img src="<?php echo e(Storage::url('images/users/' . auth()->user()->image)); ?>"
                                        alt="<?php echo e(auth()->user()->name); ?>">
                                <?php else: ?>
                                    <span>
                                        <?php echo e(strtoupper(collect(explode(' ', Auth::user()->name))->map(fn($word) => $word[0])->take(2)->implode(''))); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="user-info">
                                <span class="lead-text"><?php echo e($user->name); ?></span>
                                <span class="sub-text"><?php echo e($user->email); ?></span>
                            </div>
                            <div class="user-action">
                                <div class="dropdown">
                                    <a class="btn btn-icon btn-trigger me-n2" data-bs-toggle="dropdown" href="#"><em
                                            class="icon ni ni-more-v"></em></a>
                                    <div class="dropdown-menu dropdown-menu-end">
                                        <ul class="link-list-opt no-bdr">
                                            <li>
                                                <a href="#">
                                                    <em class="icon ni ni-camera-fill"></em>
                                                    <span>Change Photo</span>
                                                </a>
                                            </li>
                                            <?php if(Auth::user()->level->level_nama == 'Administrator'): ?>
                                                <li>
                                                    <a href="<?php echo e(route('profile.edit')); ?>">
                                                        <em class="icon ni ni-edit-fill"></em>
                                                        <span>Edit Profile</span>
                                                    </a>
                                                </li>
                                            <?php elseif(Auth::user()->level->level_nama == 'Dosen'): ?>
                                                <li>
                                                    <a href="<?php echo e(route('profile.edit')); ?>">
                                                        <em class="icon ni ni-edit-fill"></em>
                                                        <span>Edit Profile</span>
                                                    </a>
                                                </li>
                                            <?php elseif(Auth::user()->level->level_nama == 'Mahasiswa'): ?>
                                                <li>
                                                    <a href="<?php echo e(route('profile.edit')); ?>">
                                                        <em class="icon ni ni-edit-fill"></em>
                                                        <span>Edit Profile</span>
                                                    </a>
                                                </li>
                                            <?php else: ?>
                                                <li>
                                                    <a href="<?php echo e(route('profile.edit')); ?>">
                                                        <em class="icon ni ni-edit-fill"></em>
                                                        <span>Edit Profile</span>
                                                    </a>
                                                </li>
                                            <?php endif; ?>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div><!-- .user-card -->
                    </div><!-- .card-inner -->
                    <div class="card-inner p-0">
                        <ul class="link-list-menu">
                            <li class="nk-menu-item">
                                <a class="nk-menu-link" href="<?php echo e(route('profile')); ?>"><em
                                        class="icon ni ni-user-fill-c"></em><span>Personal Infomation</span></a>
                            </li>
                            <?php if(Auth::user()->level->level_nama == 'Mahasiswa'): ?>
                                <li class="nk-menu-item">
                                    <a class="nk-menu-link" href="<?php echo e(route('profil-akademik.index')); ?>"><em
                                            class="icon ni ni-user-list-fill"></em><span>Profile Akademik</span></a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </div><!-- .card-inner -->
                </div><!-- .card-inner-group -->
            </div><!-- card-aside -->
        </div><!-- .card-aside-wrap -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\raki\Documents\raki4\vsga\prod\Internify\resources\views/mahasiswa/profilAkademik/index.blade.php ENDPATH**/ ?>