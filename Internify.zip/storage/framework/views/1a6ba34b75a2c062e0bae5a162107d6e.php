<!DOCTYPE html>
<html lang="zxx" class="js">

<head>
    <base href="../">
    <meta charset="utf-8">
    <meta name="author" content="Softnio">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description"
        content="A powerful and conceptual apps base dashboard template that especially build for developers and programmers.">
    <!-- Fav Icon  -->
    <link rel="shortcut icon" href="<?php echo e(asset('assets/admin/images/icon.png')); ?>">
    <!-- Page Title  -->
    <title>Home | Internify</title>
    <!-- StyleSheets  -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/home/css/dashlite.css')); ?>">
    
    <link id="skin-default" rel="stylesheet" href="<?php echo e(asset('assets/home/css/theme.css')); ?>">
</head>

<body class="nk-body bg-white npc-landing ">
    <div class="nk-app-root">
        <!-- main @s -->
        <div class="nk-main ">
            <!-- .header-main-->
            <?php echo $__env->make('listing.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- .header -->
            <section class="section section-service pb-7">
                <div class="container">
                    <div class="section-content">
                        <?php echo $__env->yieldContent('main'); ?>
                    </div><!-- .section-content -->
                </div><!-- .container -->
            </section><!-- .section -->
            <!-- .section -->
            <?php echo $__env->make('listing.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- .footer -->
        </div>
        <!-- main @e -->
    </div>
    <!-- app-root @e -->
    <!-- JavaScript -->
    <script src="<?php echo e(asset('assets/home/js/bundle.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/home/js/scripts.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\Users\raki\Documents\raki4\pbl\raki\Internify\resources\views/listing/main.blade.php ENDPATH**/ ?>