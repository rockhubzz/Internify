<?php $__env->startSection('action'); ?>
<style>
    #quill-editor{
        overflow-x: auto;
        word-wrap: break-word;
    }
    .ql-editor {
        word-break: break-word;
    }
</style>

    <li class="nk-block-tools-opt">
        <a href="<?php echo e(route('laporan')); ?>" class="btn btn-light">
            <em class="icon ni ni-arrow-left"></em>
            <span>Kembali</span>
        </a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card card-bordered">
        <div class="card-inner">
            <div class="row gy-4">
                <div class="col-md-6">
                    <h6 class="mb-1 text-soft">Nama Mahasiswa</h6>
                    <p class="fw-bold"><?php echo e($log->mahasiswa->user->name ?? '-'); ?></p>
                </div>
                <div class="col-md-6">
                    <h6 class="mb-1 text-soft">Dosen Pembimbing</h6>
                    <p class="fw-bold"><?php echo e($log->dosen->user->name ?? '-'); ?></p>
                </div>
                <div class="col-12">
                    <h6 class="mb-1 text-soft">Laporan</h6>
                    <div class="border rounded p-3 bg-light">
                        <div id="quill-report" style="height: 150px;"><?php echo old('report_text', $log->report_text); ?></div>
                    </div>
                </div>
                <div class="col-md-6">
                    <h6 class="mb-1 text-soft">Tanggal Dibuat</h6>
                    <p class="fw-bold"><?php echo e($log->created_at->format('d M Y')); ?></p>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\raki\Documents\raki4\vsga\prod\Internify\resources\views/mahasiswa/laporan/show.blade.php ENDPATH**/ ?>