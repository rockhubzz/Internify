<div class="nk-sidebar nk-sidebar-fixed is-dark " data-content="sidebarMenu">
    <div class="nk-sidebar-element nk-sidebar-head">
        <div class="nk-menu-trigger">
            <a href="#" class="nk-nav-toggle nk-quick-nav-icon d-xl-none" data-target="sidebarMenu">
                <em class="icon ni ni-arrow-left"></em>
            </a>
            <a href="#" class="nk-nav-compact nk-quick-nav-icon d-none d-xl-inline-flex" data-target="sidebarMenu">
                <em class="icon ni ni-menu"></em>
            </a>
        </div>
        <div class="nk-sidebar-brand">
            <a href="<?php echo e(route('welcome.index')); ?>" class="logo-link nk-sidebar-logo">
                <img class="logo-light logo-img" src="<?php echo e(asset('assets/home/images/logo.png')); ?>"
                    srcset="<?php echo e(asset('assets/home/images/logo2x.png 2x')); ?>" alt="logo">
                <img class="logo-dark logo-img" src="<?php echo e(asset('assets/home/images/logo-dark.png')); ?>"
                    srcset="<?php echo e(asset('assets/home/images/logo-dark2x.png 2x')); ?>" alt="logo-dark">
            </a>
        </div>
    </div>
    <!-- .nk-sidebar-element -->
    <div class="nk-sidebar-element nk-sidebar-body">
        <div class="nk-sidebar-content">
            <div class="nk-sidebar-menu" data-simplebar>
                <ul class="nk-menu">
                    <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <!-- .nk-menu-item -->
                </ul>
                <!-- .nk-menu -->
            </div>
            <!-- .nk-sidebar-menu -->
        </div>
        <!-- .nk-sidebar-content -->
    </div>
    <!-- .nk-sidebar-element -->
</div>
<?php /**PATH C:\Users\raki\Documents\raki4\vsga\prod\Internify\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>