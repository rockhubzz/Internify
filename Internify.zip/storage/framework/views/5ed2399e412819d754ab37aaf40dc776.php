<?php $__env->startSection('content'); ?>
    <div class="card card-bordered card-preview">
        <div class="card-inner">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('profil-akademik.store')); ?>" enctype="multipart/form-data"
                class="form-validate is-alter">
                <?php echo csrf_field(); ?>
                <div class="row g-4">
                    <?php $__currentLoopData = [
            'bidang_keahlian' => 'Bidang Keahlian',
            'sertifikasi' => 'Sertifikasi',
            'pengalaman' => 'Pengalaman',
            'etika' => 'Etika',
            'ipk' => 'IPK',
        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label class="form-label" for="<?php echo e($field); ?>"><?php echo e($label); ?>

                                    <?php if(in_array($field, ['etika', 'ipk'])): ?>
                                        <span class="text-danger">*</span>
                                    <?php endif; ?>
                                </label>
                                <div class="form-control-wrap">
                                    <input type="file" class="form-control" id="<?php echo e($field); ?>"
                                        name="<?php echo e($field); ?>" <?php if(in_array($field, ['etika', 'ipk'])): ?> required <?php endif; ?>>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="col-12 text-end">
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">Simpan</button>
                            <a href="<?php echo e(route('profil-akademik.index')); ?>" class="btn btn-secondary">Kembali</a>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\raki\Documents\raki4\vsga\prod\Internify\resources\views/mahasiswa/profilAkademik/create.blade.php ENDPATH**/ ?>