<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <div class="card card-bordered card-preview">
        <div class="card-inner table-responsive">
            <table class="datatable-init-export nowrap nk-tb-list nk-tb-ulist" data-auto-responsive="false">
                <thead>
                    <tr class="nk-tb-item nk-tb-head">
                        <th class="nk-tb-col export-col"><span class="sub-text">Mahasiswa</span></th>
                        
                        <th class="nk-tb-col export-col"><span class="sub-text">Judul Laporan</span></th>
                        <th class="nk-tb-col export-col"><span class="sub-text">Laporan</span></th>
                        <th class="nk-tb-col export-col"><span class="sub-text">Tanggal</span></th>
                        <th class="nk-tb-col export-col"><span class="sub-text">Status</span></th>
                        <th class="nk-tb-col nk-tb-col-tools text-end"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="nk-tb-item">
                            <td class="nk-tb-col">
                                <div class="user-card">
                                    <div class="user-avatar bg-teal-dim d-none d-sm-flex">
                                        <?php if($log->mahasiswa->user->image): ?>
                                            <img src="<?php echo e(Storage::url('images/users/' . $log->mahasiswa->user->image)); ?>"
                                                alt="<?php echo e($log->mahasiswa->user->name); ?>">
                                        <?php else: ?>
                                            <span>
                                                <?php echo e(strtoupper(collect(explode(' ', $log->mahasiswa->user->name))->map(fn($word) => $word[0])->take(2)->implode(''))); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="user-info">
                                        <span class="tb-lead"><?php echo e($log->mahasiswa->user->name); ?><span
                                                class="dot dot-success d-md-none ms-1"></span></span>
                                        <span><?php echo e($log->mahasiswa->user->email); ?></span>
                                    </div>
                                </div>
                            </td>
                            <td class="nk-tb-col">
                                <span><?php echo e($log->report_title); ?></span>
                            </td>
                            <td class="nk-tb-col">
                                <?php if($log->file_path): ?>
                                    <a href="<?php echo e(route('laporan.download', $log->log_id)); ?>" class="btn btn-sm btn-outline-primary"
                                        download>
                                        <em class="icon ni ni-download"></em> Download
                                    </a>
                                <?php else: ?>
                                    <span class="text-muted">Belum ada</span>
                                <?php endif; ?>
                            </td>
                            <td class="nk-tb-col">
                                <span><?php echo e($log->created_at->format('d M Y')); ?></span>
                            </td>
                            <td class="nk-tb-col">
                                <?php if($log->verif_company === 'Disetujui'): ?>
                                    <span class="tb-status text-success">Verified</span>
                                <?php elseif($log->verif_company === 'Ditolak'): ?>
                                    <span class="tb-status text-danger">Ditolak</span>
                                <?php elseif($log->verif_company === 'Pending'): ?>
                                    <span class="tb-status text-warning">Pending</span>
                                <?php else: ?>
                                    <span class="tb-status text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td class="nk-tb-col nk-tb-col-tools">
                                <ul class="nk-tb-actions gx-1">
                                    <li>
                                        <div class="drodown">
                                            <a href="#" class="dropdown-toggle btn btn-icon btn-trigger"
                                                data-bs-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                            <div class="dropdown-menu dropdown-menu-end">
                                                <ul class="link-list-opt no-bdr">
                                                    <li>
                                                        <a href="<?php echo e(route('company.verifikasi.show', $log->log_id)); ?>">
                                                            <em class="icon ni ni-eye"></em>
                                                            <span>Lihat Detail</span>
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\raki\Documents\raki4\vsga\prod\Internify\resources\views/company/verifikasi.blade.php ENDPATH**/ ?>