

<?php $__env->startSection('content'); ?>
    <div class="container">

        <?php if(Auth::user()->getRole() === 'Mahasiswa'): ?>
            <?php if($notif_magang_list->isNotEmpty()): ?>
                <?php $__currentLoopData = $notif_magang_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card shadow-sm border-0 mb-3">
                        <div class="card-body d-flex align-items-start">
                            <div class="me-3">
                                <?php if($notif['m_status'] === 'Ditolak'): ?>
                                    <em class="icon icon-circle bg-danger-dim ni ni-cross fs-2 text-danger"></em>
                                <?php elseif($notif['m_status'] === 'Disetujui'): ?>
                                    <em class="icon icon-circle bg-success-dim ni ni-check fs-2 text-success"></em>
                                <?php elseif($notif['m_status'] === 'Pending'): ?>
                                    <em class="icon icon-circle bg-warning-dim ni ni-clock fs-2 text-warning"></em>
                                <?php else: ?>
                                    <em class="icon icon-circle bg-secondary-dim ni ni-info fs-2 text-muted"></em>
                                <?php endif; ?>
                            </div>
                            <div>
                                <p class="mb-1">
                                    Lamaran magang anda di <strong><?php echo e($notif['m_company_name']); ?></strong>
                                    <?php if($notif['m_status'] === 'Pending'): ?>
                                        sedang <strong>diproses</strong>.
                                    <?php else: ?>
                                        telah <strong><?php echo e(strtolower($notif['m_status'])); ?></strong>
                                    <?php endif; ?>
                                </p>
                                <small class="text-muted">
                                    <em class="ni ni-clock me-1"></em><?php echo e($notif['m_time']); ?>

                                </small>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <div class="alert alert-info" role="alert">
                    <em class="ni ni-info me-1"></em> Belum ada notifikasi terbaru.
                </div>
            <?php endif; ?>

        <?php elseif(Auth::user()->getRole() === 'Company'): ?>
            <?php if($notif_pending_list->isNotEmpty()): ?>
                <?php $__currentLoopData = $notif_pending_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card shadow-sm border-0 mb-3">
                        <div class="card-body d-flex align-items-start">
                            <div class="me-3">
                                <em class="icon icon-circle bg-warning-dim ni ni-clock fs-2 text-warning"></em>
                            </div>
                            <div>
                                <p class="mb-1">
                                    <strong><?php echo e($item['c_mahasiswa_name']); ?></strong> menunggu review magang
                                    di posisi <strong><?php echo e($item['c_lowongan_title']); ?></strong>.
                                </p>
                                <small class="text-muted">
                                    <em class="ni ni-clock me-1"></em><?php echo e($item['c_created_at']); ?>

                                </small>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <div class="alert alert-info" role="alert">
                    <em class="ni ni-info me-1"></em> Belum ada lamaran magang yang menunggu review.
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\raki\Documents\raki4\pbl\raki\Internify\resources\views/notif/index.blade.php ENDPATH**/ ?>