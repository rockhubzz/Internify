<?php $__env->startSection('action'); ?>
    <li class="nk-block-tools-opt">
        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-light">
            <em class="icon ni ni-arrow-left"></em>
            <span>Kembali</span>
        </a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card card-bordered">
        <div class="card-inner">
            <h5 class="title mb-3">Detail Mahasiswa</h5>
            <div class="row gy-3">
                <div class="col-md-6">
                    <h6 class="text-soft mb-1">NIM</h6>
                    <p class="fw-bold"><?php echo e($magang->mahasiswas->nim); ?></p>
                </div>
                <div class="col-md-6">
                    <h6 class="text-soft mb-1">Nama Mahasiswa</h6>
                    <p class="fw-bold"><?php echo e($magang->mahasiswas->user->name); ?></p>
                </div>
                <div class="col-md-6">
                    <h6 class="text-soft mb-1">Program Studi</h6>
                    <p class="fw-bold"><?php echo e($magang->mahasiswas->prodi->name); ?></p>
                </div>
                <div class="col-md-6">
                    <h6 class="text-soft mb-1">Alamat</h6>
                    <p class="fw-bold"><?php echo e($magang->mahasiswas->alamat); ?></p>
                </div>
                <div class="col-md-6">
                    <h6 class="text-soft mb-1">No. Telp</h6>
                    <p class="fw-bold"><?php echo e($magang->mahasiswas->no_telp); ?></p>
                </div>
            </div>

            <hr class="my-4">

            <h5 class="title mb-3">Detail Magang</h5>
            <div class="row gy-3">
                <div class="col-md-6">
                    <h6 class="text-soft mb-1">ID Lowongan</h6>
                    <p class="fw-bold"><?php echo e($magang->lowongans->lowongan_id); ?></p>
                </div>
                <div class="col-md-6">
                    <h6 class="text-soft mb-1">Nama Perusahaan</h6>
                    <p class="fw-bold"><?php echo e($magang->lowongans->company->user->name); ?></p>
                </div>
                <div class="col-md-6">
                    <h6 class="text-soft mb-1">Judul Magang</h6>
                    <p class="fw-bold"><?php echo e($magang->lowongans->title); ?></p>
                </div>
                <div class="col-md-6">
                    <h6 class="text-soft mb-1">Kriteria</h6>
                    <p class="fw-bold"><?php echo $magang->lowongans->requirements; ?></p>
                </div>
                <div class="col-md-12">
                    <h6 class="text-soft mb-1">Deskripsi</h6>
                    <p class="fw-bold"><?php echo $magang->lowongans->description; ?></p>
                </div>
                <div class="col-md-6">
                    <h6 class="text-soft mb-1">Periode Awal</h6>
                    <p class="fw-bold"><?php echo e($magang->lowongans->period->start_date); ?></p>
                </div>
                <div class="col-md-6">
                    <h6 class="text-soft mb-1">Periode Akhir</h6>
                    <p class="fw-bold"><?php echo e($magang->lowongans->period->end_date); ?></p>
                </div>
                <div class="col-md-6">
                    <h6 class="text-soft mb-1">Status Lamaran</h6>
                    <p class="fw-bold"><?php echo e(ucfirst($magang->status)); ?></p>
                </div>
            </div>

            <?php if(strtolower($magang->status) === 'pending'): ?>
                <div class="mt-4">
                    <form action="<?php echo e(route('admin.magangApplication.update', $magang->magang_id)); ?>"
                        method="POST" class="d-inline"
                        onsubmit="return confirm('Apakah Anda yakin menyetujui lamaran ini?')">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <input type="hidden" name="status" value="Disetujui">
                        <button type="submit" class="btn btn-success">Setujui</button>
                    </form>

                    <form action="<?php echo e(route('admin.magangApplication.update', $magang->magang_id)); ?>"
                        method="POST" class="d-inline"
                        onsubmit="return confirm('Apakah Anda yakin menolak lamaran ini?')">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <input type="hidden" name="status" value="Ditolak">
                        <button type="submit" class="btn btn-danger">Tolak</button>
                    </form>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\raki\Documents\raki4\pbl\raki\Internify\resources\views/admin/lamaranMagang/show.blade.php ENDPATH**/ ?>