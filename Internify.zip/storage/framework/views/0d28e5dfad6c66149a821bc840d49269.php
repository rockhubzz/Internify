<header class="header has-header-main-s1 bg-dark" id="home">
    <div class="header-main header-main-s1 is-sticky is-transparent on-dark">
        <div class="container header-container">
            <div class="header-wrap">
                <div class="header-logo">
                    <a href="<?php echo e(route('welcome.index')); ?>" class="logo-link">
                        <img class="logo-light logo-img" src="<?php echo e(asset('assets/home/images/logo.png')); ?>"
                            srcset="<?php echo e(asset('assets/home/images/logo2x.png 2x')); ?>" alt="logo">
                        <img class="logo-dark logo-img" src="<?php echo e(asset('assets/home/images/logo-dark.png')); ?>"
                            srcset="<?php echo e(asset('assets/home/images/logo-dark2x.png 2x')); ?>" alt="logo-dark">
                    </a>
                </div>
                <div class="header-toggle">
                    <button class="menu-toggler" data-target="mainNav">
                        <em class="menu-on icon ni ni-menu"></em>
                        <em class="menu-off icon ni ni-cross"></em>
                    </button>
                </div>
                <!-- .header-nav-toggle -->
                <nav class="header-menu" data-content="mainNav">
                    <ul class="menu-list ms-lg-auto">
                        <li class="menu-item <?php echo e(request()->routeIs('welcome.index') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('welcome.index')); ?>" class="menu-link nav-link">Home</a>
                        </li>
                        <li class="menu-item <?php echo e(request()->routeIs('list.lowongan') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('list.lowongan')); ?>" class="menu-link nav-link">Lowongan</a>
                        </li>
                        <li class="menu-item ">
                            <a href="<?php echo e(route('list.perusahaan')); ?>" class="menu-link nav-link">Company</a>
                        </li>
                    </ul>
                    <?php if(auth()->guard()->check()): ?>
                        <div class="nk-header-tools">
                            <ul class="nk-quick-nav">
                                <li class="dropdown user-dropdown menu-item">
                                    <a href="#" class="dropdown-toggle" data-bs-toggle="dropdown">
                                        <div class="user-toggle">
                                            <div class="user-info d-none d-md-block">
                                                <div class="menu-link nav-link">
                                                    Hello, <?php echo e(Auth::user()->name); ?>

                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-md dropdown-menu-end dropdown-menu-s1">
                                        <div class="dropdown-inner user-card-wrap bg-lighter d-none d-md-block">
                                            <div class="user-card">
                                                <div class="user-avatar">
                                                    <span>
                                                        <?php echo e(strtoupper(collect(explode(' ', Auth::user()->name))->map(fn($word) => $word[0])->take(2)->implode(''))); ?>

                                                    </span>
                                                </div>
                                                <div class="user-info">
                                                    <span class="lead-text"><?php echo e(Auth::user()->name ?? 'Guest'); ?></span>
                                                    <span class="sub-text"><?php echo e(Auth::user()->email ?? 'Guest'); ?></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="dropdown-inner py-3">
                                            <ul class="link-list ">
                                                <?php if(Auth::user()->level->level_nama == 'Administrator'): ?>
                                                    <li>
                                                        <a href="<?php echo e(route('admin.dashboard')); ?>">
                                                            <em class="icon ni ni-dashlite"></em>
                                                            <span>Dashboard</span>
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="<?php echo e(route('profile')); ?>">
                                                            <em class="icon ni ni-user-alt"></em>
                                                            <span>View Profile</span>
                                                        </a>
                                                    </li>
                                                <?php elseif(Auth::user()->level->level_nama == 'Mahasiswa'): ?>
                                                    <li>
                                                        <a href="<?php echo e(route('mahasiswa.dashboard')); ?>">
                                                            <em class="icon ni ni-dashlite"></em>
                                                            <span>Dashboard</span>
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="<?php echo e(route('profile')); ?>">
                                                            <em class="icon ni ni-user-alt"></em>
                                                            <span>View Profile</span>
                                                        </a>
                                                    </li>
                                                <?php elseif(Auth::user()->level->level_nama == 'Dosen'): ?>
                                                    <li>
                                                        <a href="<?php echo e(route('dosen.dashboard')); ?>">
                                                            <em class="icon ni ni-dashlite"></em>
                                                            <span>Dashboard</span>
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="<?php echo e(route('profile')); ?>">
                                                            <em class="icon ni ni-user-alt"></em>
                                                            <span>View Profile</span>
                                                        </a>
                                                    </li>
                                                <?php elseif(Auth::user()->level->level_nama == 'Company'): ?>
                                                    <li>
                                                        <a href="<?php echo e(route('company.dashboard')); ?>">
                                                            <em class="icon ni ni-dashlite"></em>
                                                            <span>Dashboard</span>
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="<?php echo e(route('profile')); ?>">
                                                            <em class="icon ni ni-user-alt"></em>
                                                            <span>View Profile</span>
                                                        </a>
                                                    </li>
                                                <?php endif; ?>
                                                
                                            </ul>
                                        </div>
                                        <div class="dropdown-inner py-3">
                                            <ul class="link-list">
                                                <li>
                                                    <a href="<?php echo e(route('logout')); ?>">
                                                        <em class="icon ni ni-signout"></em>
                                                        <span>Sign out</span>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    <?php else: ?>
                        <div class="nk-header-tools">
                            <ul class="nk-quick-nav">
                                <li>
                                    <a href="<?php echo e(route('login')); ?>" class="btn btn-primary btn-lg">Masuk</a>
                                </li>
                            </ul>
                        </div>
                    <?php endif; ?>
                </nav>
                <!-- .nk-nav-menu -->
            </div>
            <!-- .header-warp-->
        </div>
        <!-- .container-->
    </div>
    <!-- .header-main-->
    <div class="header-content my-auto py-6 is-dark">
        <div class="container mt-n4 mt-lg-0">
            <div class="row flex-lg-row-reverse align-items-center justify-content-between g-gs">
                <div class="col-lg-6 mb-lg-0">
                    
                </div>
                <!-- .col- -->
                <div class="col-lg-6 col-md-10">
                    <div class="header-caption">
                        <div class="header-rating rating">
                            <ul class="rating-stars">
                                <li>
                                    <em class="icon ni ni-star-fill"></em>
                                </li>
                                <li>
                                    <em class="icon ni ni-star-fill"></em>
                                </li>
                                <li>
                                    <em class="icon ni ni-star-fill"></em>
                                </li>
                                <li>
                                    <em class="icon ni ni-star-fill"></em>
                                </li>
                                <li>
                                    <em class="icon ni ni-star-fill"></em>
                                </li>
                            </ul>
                            
                        </div>
                        <h1 class="header-title fw-medium">Kelola Magang Lebih Mudah, Terstruktur, dan
                            Terintegrasi</h1>
                        <div class="header-text">
                            <p>Sistem Manajemen Magang modern untuk institusi, mahasiswa, dan mitra
                                industri.
                            </p>
                        </div>
                        <ul class="header-action btns-inline">
                            <li>
                                <?php if(auth()->guard()->guest()): ?>
                                    <a href="<?php echo e(route('login')); ?>" class="btn btn-primary btn-lg btn-round">
                                        Ayo Mulai!
                                    </a>
                                <?php endif; ?>
                            </li>
                        </ul>
                    </div>
                    <!-- .header-caption -->
                </div>
                <!-- .col -->
            </div>
            <!-- .row -->
        </div>
        <!-- .container -->
    </div>
    <!-- .header-content -->
    <div class="bg-image bg-overlay after-bg-dark after-opacity-95">
        <img src="<?php echo e(asset('assets/home/images/bg/gedungjti.png')); ?>" alt="">
    </div>
</header><?php /**PATH C:\Users\raki\Documents\raki4\vsga\prod\Internify\resources\views/home/header.blade.php ENDPATH**/ ?>