<?php $__env->startSection('action'); ?>
    <li class="nk-block-tools-opt">
        <a href="<?php echo e(route('company.verifikasi')); ?>" class="btn btn-light">
            <em class="icon ni ni-arrow-left"></em>
            <span>Kembali</span>
        </a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card card-bordered">
        <div class="card-inner">
            <div class="row gy-4">
                <div class="col-md-6">
                    <h6 class="mb-1 text-soft">Nama Mahasiswa</h6>
                    <p class="fw-bold"><?php echo e($log->mahasiswa->user->name ?? '-'); ?></p>
                </div>
                <div class="col-md-6">
                    <h6 class="mb-1 text-soft">Dosen Pembimbing</h6>
                    <p class="fw-bold"><?php echo e($log->dosen->user->name ?? '-'); ?></p>
                </div>
                <div class="col-md-6">
                    <h6 class="mb-1 text-soft">Judul Laporan</h6>
                    <p class="fw-bold"><?php echo e($log->report_title ?? '-'); ?></p>
                </div>
                <div class="col-12">
                    <h6 class="mb-1 text-soft">Lampiran</h6>
                    <?php if($log->file_path): ?>
                        <a href="<?php echo e(route('laporan.download', $log->log_id)); ?>" class="btn btn-sm btn-outline-primary" download>
                            <em class="icon ni ni-download"></em> Download
                        </a>
                    <?php else: ?>
                        <span class="text-muted">Belum ada</span>
                    <?php endif; ?>

                </div>
                <div class="col-12">
                    <h6 class="mb-1 text-soft">Laporan</h6>
                    <div class="border rounded p-3 bg-light">
                        <div id="quill-report" style="height: 150px;"><?php echo old('report_text', $log->report_text); ?></div>
                    </div>
                </div>
                <div class="col-md-6">
                    <h6 class="mb-1 text-soft">Tanggal Dibuat</h6>
                    <p class="fw-bold"><?php echo e($log->created_at->format('d M Y')); ?></p>
                </div>
                <div class="col-md-6 text-end">
                    <form action="<?php echo e(route('company.verifikasi.update', $log->log_id)); ?>" method="POST"
                        style="display: inline;" onsubmit="return confirm('Apakah anda yakin menyetujui laporan ini?')">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <input type="hidden" name="verif_company" value="Disetujui">
                        <button type="submit" class="btn btn-link p-0 m-0 align-baseline text-light"
                            style="background: rgb(32, 155, 32)">
                            <span style="padding:5px;">Setuju</span></button>
                    </form>

                    <form action="<?php echo e(route('company.verifikasi.update', $log->log_id)); ?>" method="POST"
                        style="display: inline;" onsubmit="return confirm('Apakah anda yakin menolak laporan ini?')">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <input type="hidden" name="verif_company" value="Ditolak">
                        <button type="submit" class="btn btn-link p-0 m-0 align-baseline text-light"
                            style="background: red;">
                            <span style="padding: 5px;">Tolak</span>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\raki\Documents\raki4\vsga\prod\Internify\resources\views/company/show.blade.php ENDPATH**/ ?>