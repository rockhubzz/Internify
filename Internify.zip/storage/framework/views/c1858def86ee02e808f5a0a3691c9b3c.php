<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Tambah Perusahaan Mitra</h2>
    <form action="<?php echo e(route('companies.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label>Nama Perusahaan</label>
            <input type="text" name="name" class="form-control" required>
        </div>
        
        <div class="form-group mt-2">
            <label>Bidang Industri</label>
            <input type="text" name="industry" class="form-control">
        </div>

        <div class="form-group mt-2">
            <label>Alamat</label>
            <input type="text" name="address" class="form-control">
        </div>
        
        <div class="form-group mt-2">
            <label>Kontak</label>
            <input type="text" name="contact" class="form-control">
        </div>


        <button type="submit" class="btn btn-success mt-3">Simpan</button>
        <a href="<?php echo e(route('companies.index')); ?>" class="btn btn-secondary mt-3">Kembali</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\raki\Documents\raki4\pbl\Internify\resources\views/company/create.blade.php ENDPATH**/ ?>