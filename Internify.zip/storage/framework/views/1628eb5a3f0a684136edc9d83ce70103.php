<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="row justify-content-center">
        <div class="col-md-8 col-lg-6" style="width: 80%; height: 100%;">
            <div class="card card-bordered card-preview">
                <div class="card-inner">
                    <table class="table table-bordered table-striped table-hover table-sm mb-3">
                        <tr>
                            <th>Bidang Keahlian</th>
                            <td><?php echo e($profilAkademik->bidang_keahlian); ?></td>
                        </tr>
                        <tr>
                            <th>Sertifikasi</th>
                            <td><?php echo e($profilAkademik->sertifikasi); ?></td>
                        </tr>
                        <tr>
                            <th>Lokasi</th>
                            <td><?php echo e($profilAkademik->lokasi); ?></td>
                        </tr>
                        <tr>
                            <th>Pengalaman</th>
                            <td><?php echo e($profilAkademik->pengalaman); ?></td>
                        </tr>
                        <tr>
                            <th>Etika</th>
                            <td><?php echo e($profilAkademik->etika); ?></td>
                        </tr>
                        <tr>
                            <th>IPK</th>
                            <td><?php echo e($profilAkademik->ipk); ?></td>
                        </tr>
                    </table>

                    <div class="d-flex justify-content-between">
                        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary">Kembali</a>
                        <a href="<?php echo e(route('profil-akademik.edit')); ?>" class="btn btn-warning">Edit Profil Akademik</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\raki\Documents\raki4\pbl\raki\Internify\resources\views/mahasiswa/profilAkademik/index.blade.php ENDPATH**/ ?>