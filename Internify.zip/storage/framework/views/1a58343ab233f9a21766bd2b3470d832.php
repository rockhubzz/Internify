


<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <h4>Detail Mahasiswa</h4>
<table class="table table-bordered table-striped table-hover table-sm" style="width: 30%">
    <tr>
        <th>NIM</th>
    <td><?php echo e($magang->student->nim); ?></td>
</tr>
<tr>
    <th>Nama Mahasiswa</th>
    <td><?php echo e($magang->student->user->name); ?></td>
</tr>
<tr>
    <th>Prodi</th>
    <td><?php echo e($magang->student->prodi->name); ?></td>
</tr>
<tr>
    <th>Alamat</th>
    <td><?php echo e($magang->student->alamat); ?></td>
</tr>
<tr>
    <th>No. Telp</th>
    <td><?php echo e($magang->student->no_telp); ?></td>
</tr>

</table>

<h4>Detail Magang</h4>
<table class="table table-bordered table-striped table-hover table-sm" style="width: 30%">
    <tr>
        <th>ID</th>
    <td><?php echo e($magang->lowongan->lowongan_id); ?></td>
</tr>
<tr>
    <th>Nama Perusahaan</th>
    <td><?php echo e($magang->lowongan->company->name); ?></td>
</tr>
<tr>
    <th>Judul Magang</th>
    <td><?php echo e($magang->lowongan->title); ?></td>
</tr>
<tr>
    <th>Deskripsi</th>
    <td><?php echo e($magang->lowongan->description); ?></td>
</tr>
<tr>
    <th>Periode Awal</th>
    <td><?php echo e($magang->lowongan->period->start_date); ?></td>
</tr>
    <th>Periode Akhir</th>
    <td><?php echo e($magang->lowongan->period->end_date); ?></td>
</tr>
<tr>
    <th>Kriteria</th>
    <td><?php echo e($magang->lowongan->requirements); ?></td>
</tr>
</table>
<?php if(Auth::user()->level_id == 1): ?>
    <a href="<?php echo e(route('lowonganMagang.index')); ?>" class="btn btn-secondary">Kembali</a>
<?php endif; ?>

<?php if(Auth::user()->level_id == 2): ?>
    <a href="<?php echo e(route('lowonganMagang.indexMhs')); ?>" class="btn btn-secondary">Kembali</a>
<?php endif; ?>


</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\raki\Documents\raki4\pbl\Internify\resources\views/magangApplication/show.blade.php ENDPATH**/ ?>