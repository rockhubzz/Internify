<?php $__env->startSection('content'); ?>
    <div class="card card-bordered card-preview">
        <div class="card-inner">
            <form action="<?php echo e(route('laporan.update', $logs->log_id)); ?>" enctype="multipart/form-data"
                method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="row g-4">
                    <input type="hidden" name="mahasiswa_id" value="<?php echo e($mahasiswa->mahasiswa_id); ?>">

                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="form-label" for="dosen_id">Dosen:<span class="text-danger">*</span></label>
                            <div class="form-control-wrap">
                                <select class="form-select js-select2" name="dosen_id" required>
                                    <option disabled selected>Pilih Dosen</option>
                                    <?php $__currentLoopData = $dosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dsn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($dsn->dosen_id); ?>"><?php echo e($dsn->user->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="col-12">
                        <div class="form-group">
                            <label class="form-label" for="report_text">Isi Laporan:<span class="text-danger">*</span></label>
                            <div class="form-control-wrap">
                                <textarea class="form-control" name="report_text" rows="5" required></textarea>
                            </div>
                        </div>
                    </div>

                    <div class="col-12">
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">Simpan</button>
                            <a href="<?php echo e(route('laporan')); ?>" class="btn btn-secondary">Kembali</a>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\raki\Documents\raki4\pbl\raki\Internify\resources\views/mahasiswa/laporan/edit.blade.php ENDPATH**/ ?>