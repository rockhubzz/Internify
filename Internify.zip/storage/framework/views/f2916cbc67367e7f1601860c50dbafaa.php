<!DOCTYPE html>
<html lang="zxx" class="js">

<head>
    <base href="../">
    <meta charset="utf-8">
    <meta name="author" content="Softnio">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description"
        content="A powerful and conceptual apps base dashboard template that especially build for developers and programmers.">
    <!-- Fav Icon  -->
    <link rel="shortcut icon" href="<?php echo e(asset('assets/admin/images/icon.png')); ?>">
    <!-- Page Title  -->
    <title>Home | Internify</title>
    <!-- StyleSheets  -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/home/css/dashlite.css')); ?>">
    
    <link id="skin-default" rel="stylesheet" href="<?php echo e(asset('assets/home/css/theme.css')); ?>">
</head>

<body class="nk-body bg-white npc-landing ">
    <div class="nk-app-root">
        <!-- main @s -->
        <div class="nk-main ">
            <!-- .header-main-->
            <header class="header header-33 has-header-main-s1 bg-dark">
                <div class="header-main header-main-s1 is-sticky is-transparent on-dark">
                    <div class="container header-container">
                        <div class="header-wrap">
                            <div class="header-logo">
                                <a href="<?php echo e(route('welcome.index')); ?>" class="logo-link">
                                    <img class="logo-light logo-img" src="<?php echo e(asset('assets/home/images/logo.png')); ?>"
                                        srcset="<?php echo e(asset('assets/home/images/logo2x.png 2x')); ?>" alt="logo">
                                    <img class="logo-dark logo-img"
                                        src="<?php echo e(asset('assets/home/images/logo-dark.png')); ?>"
                                        srcset="<?php echo e(asset('assets/home/images/logo-dark2x.png 2x')); ?>" alt="logo-dark">
                                </a>
                            </div>
                            <div class="header-toggle">
                                <button class="menu-toggler" data-target="mainNav">
                                    <em class="menu-on icon ni ni-menu"></em>
                                    <em class="menu-off icon ni ni-cross"></em>
                                </button>
                            </div>
                            <!-- .header-nav-toggle -->
                            <nav class="header-menu" data-content="mainNav">
                                <ul class="menu-list ms-lg-auto">
                                    <li class="menu-item">
                                        <a href="<?php echo e(route('welcome.index')); ?>" class="menu-link nav-link ">Home</a>
                                    </li>
                                    <li class="menu-item <?php echo e(request()->routeIs('list.lowongan') ? 'active' : ''); ?>">
                                        <a href="<?php echo e(route('list.lowongan')); ?>" class="menu-link nav-link">Lowongan</a>
                                    </li>
                                    <li class="menu-item ">
                                        <a href="<?php echo e(route('list.perusahaan')); ?>" class="menu-link nav-link">Company</a>
                                    </li>
                                </ul>
                                <?php if(auth()->guard()->check()): ?>
                                    <div class="nk-header-tools">
                                        <ul class="nk-quick-nav">
                                            <li class="dropdown user-dropdown menu-item">
                                                <a href="#" class="dropdown-toggle" data-bs-toggle="dropdown">
                                                    <div class="user-toggle">
                                                        <div class="user-info d-none d-md-block">
                                                            <div class="menu-link nav-link">
                                                                Hello, <?php echo e(Auth::user()->name); ?>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </a>
                                                <div
                                                    class="dropdown-menu dropdown-menu-md dropdown-menu-end dropdown-menu-s1">
                                                    <div class="dropdown-inner user-card-wrap bg-lighter d-none d-md-block">
                                                        <div class="user-card">
                                                            <div class="user-avatar">
                                                                <span>
                                                                    <?php echo e(strtoupper(collect(explode(' ', Auth::user()->name))->map(fn($word) => $word[0])->take(2)->implode(''))); ?>

                                                                </span>
                                                            </div>
                                                            <div class="user-info">
                                                                <span
                                                                    class="lead-text"><?php echo e(Auth::user()->name ?? 'Guest'); ?></span>
                                                                <span
                                                                    class="sub-text"><?php echo e(Auth::user()->email ?? 'Guest'); ?></span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="dropdown-inner py-3">
                                                        <ul class="link-list ">
                                                            <?php if(Auth::user()->level->level_nama == 'Administrator'): ?>
                                                                <li>
                                                                    <a href="<?php echo e(route('admin.dashboard')); ?>">
                                                                        <em class="icon ni ni-dashlite"></em>
                                                                        <span>Dashboard</span>
                                                                    </a>
                                                                </li>
                                                                <li>
                                                                    <a href="<?php echo e(route('profile')); ?>">
                                                                        <em class="icon ni ni-user-alt"></em>
                                                                        <span>View Profile</span>
                                                                    </a>
                                                                </li>
                                                            <?php elseif(Auth::user()->level->level_nama == 'Mahasiswa'): ?>
                                                                <li>
                                                                    <a href="<?php echo e(route('mahasiswa.dashboard')); ?>">
                                                                        <em class="icon ni ni-dashlite"></em>
                                                                        <span>Dashboard</span>
                                                                    </a>
                                                                </li>
                                                                <li>
                                                                    <a href="<?php echo e(route('profile')); ?>">
                                                                        <em class="icon ni ni-user-alt"></em>
                                                                        <span>View Profile</span>
                                                                    </a>
                                                                </li>
                                                            <?php elseif(Auth::user()->level->level_nama == 'Dosen'): ?>
                                                                <li>
                                                                    <a href="<?php echo e(route('dosen.dashboard')); ?>">
                                                                        <em class="icon ni ni-dashlite"></em>
                                                                        <span>Dashboard</span>
                                                                    </a>
                                                                </li>
                                                                <li>
                                                                    <a href="<?php echo e(route('profile')); ?>">
                                                                        <em class="icon ni ni-user-alt"></em>
                                                                        <span>View Profile</span>
                                                                    </a>
                                                                </li>
                                                            <?php elseif(Auth::user()->level->level_nama == 'Company'): ?>
                                                                <li>
                                                                    <a href="<?php echo e(route('company.dashboard')); ?>">
                                                                        <em class="icon ni ni-dashlite"></em>
                                                                        <span>Dashboard</span>
                                                                    </a>
                                                                </li>
                                                                <li>
                                                                    <a href="<?php echo e(route('profile')); ?>">
                                                                        <em class="icon ni ni-user-alt"></em>
                                                                        <span>View Profile</span>
                                                                    </a>
                                                                </li>
                                                            <?php endif; ?>
                                                            
                                                        </ul>
                                                    </div>
                                                    <div class="dropdown-inner py-3">
                                                        <ul class="link-list">
                                                            <li>
                                                                <a href="<?php echo e(route('logout')); ?>">
                                                                    <em class="icon ni ni-signout"></em>
                                                                    <span>Sign out</span>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                <?php else: ?>
                                    <div class="nk-header-tools">
                                        <ul class="nk-quick-nav">
                                            <li>
                                                <a href="<?php echo e(route('login')); ?>" class="btn btn-primary btn-lg">Masuk</a>
                                            </li>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                            </nav>
                            <!-- .nk-nav-menu -->
                        </div>
                        <!-- .header-warp-->
                    </div><!-- .container-->
                </div>
                <div class="header-content py-6 is-dark mt-lg-n1 mt-n3">
                    <div class="container">
                        <!-- Job Title and Action Buttons -->
                        <div class="d-flex flex-wrap align-items-center justify-content-between">
                            <div class="d-flex align-items-center">
                                <?php if($lowongan->company->user->image): ?>
                                    <div class="user-avatar lg me-3">
                                        <img src="<?php echo e(Storage::url('images/users/' . $lowongan->company->user->image)); ?>"
                                            alt="<?php echo e($lowongan->company->user->name); ?>">
                                    </div>
                                <?php else: ?>
                                    <div class="user-avatar sq lg bg-primary me-3">
                                        <span>
                                            <?php echo e(strtoupper(collect(explode(' ', $lowongan->company->user->name))->map(fn($word) => $word[0])->take(2)->implode(''))); ?>

                                        </span>
                                    </div>
                                <?php endif; ?>
                                <div>
                                    <h4 class="mb-1"><?php echo e($lowongan->title); ?></h4>
                                    <ul class="list-inline list-split fs-14px text-soft">
                                        <li><em class="icon ni ni-building"></em> <?php echo e($lowongan->company->user->name); ?>

                                        </li>
                                        <li><em class="icon ni ni-clock"></em>
                                            <?php echo e($lowongan->created_at->diffForHumans()); ?></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="d-flex g-2 mt-3 mt-md-0">
                                <?php if(auth()->guard()->guest()): ?>
                                    <a href="<?php echo e(route('login')); ?>" class="btn btn-lg btn-primary">Lamar Cepat</a>
                                <?php endif; ?>

                                <?php if(auth()->guard()->check()): ?>
                                    <?php if(Auth::user()->level && Auth::user()->level->level_nama === 'Mahasiswa'): ?>
                                        <form action="<?php echo e(route('buatLamaran', ['id' => $lowongan->lowongan_id])); ?>"
                                            method="POST" onsubmit="return confirm('Yakin ingin melamar lowongan ini?')">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-lg btn-primary">Lamar Cepat</button>
                                        </form>
                                    <?php endif; ?>
                                <?php endif; ?>

                            </div>
                        </div>
                    </div>
                    <!-- .container -->
                </div>
                <!-- .header-main-->
            </header>
            <!-- .header-content -->
            <!-- .header -->


            <!-- .section -->
            <section class="section section-detail pb-7">
                <div class="container">
                    <div class="section-content">
                        <!-- Grid Layout -->
                        <div class="row g-gs">
                            <!-- Left Content -->
                            <div class="col-lg-8">
                                <!-- Job Description -->
                                <div class="card card-bordered mb-4">
                                    <div class="card-inner">
                                        <h5 class="title mb-3">Deskripsi Lowongan</h5>
                                        <div class="text-base">
                                            <?php echo $lowongan->description; ?>

                                        </div>
                                    </div>
                                </div>

                                <!-- Syarat & Ketentuan -->
                                <div class="card card-bordered mb-4">
                                    <div class="card-inner">
                                        <h5 class="title mb-3">Syarat & Ketentuan</h5>
                                        <div class="content-html">
                                            <?php echo $lowongan->requirements; ?>

                                        </div>
                                    </div>
                                </div>

                                <!-- Benefits -->
                                <div class="card card-bordered mb-4">
                                    <div class="card-inner">
                                        <h5 class="title mb-3">Benefit</h5>
                                        <ul class="list list-sm text-soft">
                                            <?php $__currentLoopData = $lowongan->benefits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $benefit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                
                                                <li><?php echo e($benefit->name); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                            <!-- Right Sidebar -->
                            <div class="col-lg-4">
                                <!-- Job Overview -->
                                <div class="card card-bordered mb-4">
                                    <div class="card-inner">
                                        <h6 class="title">Job Overview</h6>
                                        <ul class="gy-2 mt-3">
                                            <li class="d-flex justify-content-between"><strong>Date Posted:</strong>
                                                <?php echo e($lowongan->created_at->diffForHumans()); ?></li>
                                            <li class="d-flex justify-content-between"><strong>Expiration
                                                    Date:</strong> <?php echo e($lowongan->period->end_date); ?>

                                            </li>
                                            <li class="d-flex justify-content-between">
                                                <strong>Lokasi:</strong><?php echo e($lowongan->regency->name); ?>

                                                (<?php echo e($lowongan->province->name); ?>)

                                            </li>
                                            <li class="d-flex justify-content-between"><strong>Job Type:</strong>
                                                <?php echo e($lowongan->kategori->name); ?></li>
                                        </ul>
                                    </div>
                                </div>

                                <!-- Company Info -->
                                <div class="card card-bordered">
                                    <div class="card-inner text-center">
                                        <div class="d-flex justify-content-center mb-3">
                                            <?php if($lowongan->company->user->image): ?>
                                                <div class="user-avatar lg">
                                                    <img src="<?php echo e(Storage::url('images/users/' . $lowongan->company->user->image)); ?>"
                                                        alt="<?php echo e($lowongan->company->user->name); ?>">
                                                </div>
                                            <?php else: ?>
                                                <div class="user-avatar lg bg-indigo">
                                                    <span>
                                                        <?php echo e(strtoupper(collect(explode(' ', $lowongan->company->user->name))->map(fn($word) => $word[0])->take(2)->implode(''))); ?>

                                                    </span>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <h6 class="title mb-1"><?php echo e($lowongan->company->user->name); ?></h6>
                                        

                                            <a href="<?php echo e(route('show.perusahaan', $lowongan->company->company_id)); ?>"
                                                class="text-primary small">View company profile</a>
                                            
                                                <ul class="gy-2 mt-3">
                                                    <li class="d-flex justify-content-between">
                                                        <strong>Founded:</strong><?php echo e($lowongan->company->created_at); ?>

                                                    </li>
                                                    <li class="d-flex justify-content-between"><strong>Phone:</strong>
                                                        <?php echo e($lowongan->company->user->no_telp); ?></li>
                                                    <li class="d-flex justify-content-between"><strong>Lokasi:</strong>
                                                        <?php echo e($lowongan->company->user->alamat); ?></li>
                                                </ul>
                                                <a href="<?php echo e(route('show.perusahaan', $lowongan->company->company_id)); ?>"
                                                    class="btn btn-outline-primary btn-block mt-3">Membuka
                                                    Lowongan
                                                    : <?php echo e($jobcount); ?></a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Related Jobs -->
                        <?php if($recent->count()): ?>
                            <div class="mt-5">
                                <h5 class="mb-3">Lowongan Serupa</h5>
                                <div class="row g-4">
                                    <?php $__currentLoopData = $recent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-sm-6 col-lg-4">
                                            <a href="<?php echo e(route('show.lowongan', $job->lowongan_id)); ?>" class="card-link-wrapper">
                                                <div class="card card-bordered service service-s4 h-100">
                                                    <div class="card-inner">
                                                        <div class="job">
                                                            <div class="job-head">
                                                                <div class="job-title">
                                                                    <?php if($job->company->user->image): ?>
                                                                        <div class="user-avatar">
                                                                            <img src="<?php echo e(Storage::url('images/users/' . $job->company->user->image)); ?>"
                                                                                alt="<?php echo e($job->company->user->name); ?>">
                                                                        </div>
                                                                    <?php else: ?>
                                                                        <div class="user-avatar sq">
                                                                            <span>
                                                                                <?php echo e(strtoupper(collect(explode(' ', $job->company->user->name))->map(fn($word) => $word[0])->take(2)->implode(''))); ?>

                                                                            </span>
                                                                        </div>
                                                                    <?php endif; ?>
                                                                    <div class="job-info">
                                                                        <h6 class="title"><?php echo e($job->title); ?></h6>
                                                                        <span class="sub-text"><?php echo e($job->period->name); ?></span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="job-details">
                                                                <p><?php echo e(Str::limit(strip_tags($job->description), 80)); ?>

                                                                </p>
                                                            </div>
                                                            <div class="job-meta">
                                                                <ul class="job-users g-1">
                                                                    <li>
                                                                        <span
                                                                            class="badge badge-dim bg-primary"><?php echo e($job->kategori->name); ?></span>
                                                                    </li>
                                                                </ul>
                                                                <span class="badge badge-dim bg-warning">
                                                                    <em class="icon ni ni-clock"></em>
                                                                    <span><?php echo e($job->created_at->diffForHumans()); ?></span>
                                                                </span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div><!-- .section-content -->
                </div><!-- .container -->
            </section><!-- .section -->

            <!-- .section -->
            <?php echo $__env->make('listing.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- .footer -->
        </div>
        <!-- main @e -->
    </div>
    <!-- app-root @e -->
    <!-- JavaScript -->
    <script src="<?php echo e(asset('assets/home/js/bundle.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/home/js/scripts.js')); ?>"></script>
</body>

</html><?php /**PATH C:\Users\raki\Documents\raki4\vsga\prod\Internify\resources\views/listing/job/show.blade.php ENDPATH**/ ?>