<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="card card-bordered card-preview mb-4">
        <div class="card-inner">
            <h5 class="mb-3">Detail Mahasiswa</h5>
            <table class="table table-bordered table-striped table-hover table-sm mb-3">
                <tr>
                    <th>NIM</th>
                    <td><?php echo e($magang->mahasiswas->nim); ?></td>
                </tr>
                <tr>
                    <th>Nama Mahasiswa</th>
                    <td><?php echo e($magang->mahasiswas->user->name); ?></td>
                </tr>
                <tr>
                    <th>Prodi</th>
                    <td><?php echo e($magang->mahasiswas->prodi->name); ?></td>
                </tr>
                <tr>
                    <th>Alamat</th>
                    <td><?php echo e($magang->mahasiswas->user->alamat); ?></td>
                </tr>
                <tr>
                    <th>No. Telp</th>
                    <td>
                        <?php echo e($magang->mahasiswas->user->no_telp); ?>

                        <span class="float-end">
                            <a href="https://wa.me/<?php echo e(preg_replace('/[^0-9]/', '', $magang->mahasiswas->user->no_telp)); ?>"
                                target="_blank" class="badge bg-primary text-white text-center"
                                style="padding: 3px 10px; display: inline-block; min-width: 70px;">
                                Hubungi
                            </a>
                        </span>
                    </td>
                </tr>
            </table>
        </div>
    </div>
    <div class="card card-bordered card-preview mb-4">
        <div class="card-inner">
            <h5 class="mb-3">Detail Magang</h5>
            <table class="table table-bordered table-striped table-hover table-sm mb-3">
                <tr>
                    <th>ID</th>
                    <td><?php echo e($magang->lowongans->lowongan_id); ?></td>
                </tr>
                <tr>
                    <th>Nama Perusahaan</th>
                    <td><?php echo e($magang->lowongans->company->user->name); ?></td>
                </tr>
                <tr>
                    <th>Judul Magang</th>
                    <td><?php echo e($magang->lowongans->title); ?></td>
                </tr>
                <tr>
                    <th>Deskripsi</th>
                    <td><?php echo e($magang->lowongans->description); ?></td>
                </tr>
                <tr>
                    <th>Periode Awal</th>
                    <td><?php echo e($magang->lowongans->period->start_date); ?></td>
                </tr>
                <tr>
                    <th>Periode Akhir</th>
                    <td><?php echo e($magang->lowongans->period->end_date); ?></td>
                </tr>
                <tr>
                    <th>Kriteria</th>
                    <td><?php echo e($magang->lowongans->requirements); ?></td>
                </tr>
                <tr>
                    <th>Status</th>
                    <td><?php echo e($magang->status); ?></td>
                </tr>
            </table>
        </div>
    </div>
    <?php if($profilAkademik): ?>
        <div class="card card-bordered card-preview mb-4">
            <div class="card-inner">
                <h5 class="mb-3">Profil Akademik</h5>
                <table class="table table-bordered table-striped table-hover table-sm mb-3">
                    <tr>
                        <th>Bidang Keahlian</th>
                        <td><?php echo e($profilAkademik->bidang_keahlian ?? '-'); ?></td>
                        <td>
                            <?php if($profilAkademik?->bidang_keahlian): ?>
                                <a href="<?php echo e(asset('storage/profil-akademik/bidang_keahlian/' . $profilAkademik->bidang_keahlian)); ?>"
                                    download class="btn btn-sm btn-outline-primary">Download</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Sertifikasi</th>
                        <td><?php echo e($profilAkademik->sertifikasi ?? '-'); ?></td>
                        <td>
                            <?php if($profilAkademik?->sertifikasi): ?>
                                <a href="<?php echo e(asset('storage/profil-akademik/sertifikasi/' . $profilAkademik->sertifikasi)); ?>"
                                    download class="btn btn-sm btn-outline-primary">Download</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Pengalaman</th>
                        <td><?php echo e($profilAkademik->pengalaman ?? '-'); ?></td>
                        <td>
                            <?php if($profilAkademik?->pengalaman): ?>
                                <a href="<?php echo e(asset('storage/profil-akademik/pengalaman/' . $profilAkademik->pengalaman)); ?>"
                                    download class="btn btn-sm btn-outline-primary">Download</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Etika</th>
                        <td><?php echo e($profilAkademik->etika ?? '-'); ?></td>
                        <td>
                            <?php if($profilAkademik?->etika): ?>
                                <a href="<?php echo e(asset('storage/profil-akademik/etika/' . $profilAkademik->etika)); ?>" download
                                    class="btn btn-sm btn-outline-primary">Download</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>IPK</th>
                        <td><?php echo e($profilAkademik->ipk ?? '-'); ?></td>
                        <td>
                            <?php if($profilAkademik?->ipk): ?>
                                <a href="<?php echo e(asset('storage/profil-akademik/ipk/' . $profilAkademik->ipk)); ?>" download
                                    class="btn btn-sm btn-outline-primary">Download</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    <?php endif; ?>

    <div class="col-12 text-end">
        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary">Kembali</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\raki\Documents\raki4\pbl\raki\Internify\resources\views/company/lamaranMagang/show.blade.php ENDPATH**/ ?>