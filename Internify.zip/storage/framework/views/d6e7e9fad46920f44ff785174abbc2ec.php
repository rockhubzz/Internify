<?php $__env->startSection('content'); ?>
<div class="card card-bordered card-preview">
    <div class="card-inner">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('profilAkademik.update', $profilAkademik->profile_id)); ?>" enctype="multipart/form-data" class="form-validate is-alter">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="row g-4">

                <div class="col-lg-6">
                    <div class="form-group">
                        <label class="form-label" for="bidang_keahlian">Bidang Keahlian: <span class="text-danger">*</span></label>
                        <div class="form-control-wrap">
                            <select class="form-control" id="bidang_keahlian" name="bidang_keahlian" required>
                                    <option value="">-- Pilih bidang keahlian --</option>
                                    <?php $__currentLoopData = $kriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requirement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($requirement); ?>" <?php echo e($profilAkademik->bidang_keahlian == $requirement ? 'selected' : ''); ?>>
                                            <?php echo e($requirement); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6">
                    <div class="form-group">
                        <label class="form-label" for="sertifikasi">Sertifikasi: <span class="text-danger">*</span></label>
                        <div class="form-control-wrap">
                            <input type="text" class="form-control" id="sertifikasi" name="sertifikasi" value="<?php echo e($profilAkademik->sertifikasi); ?>" placeholder="Masukkan sertifikasi anda" required>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6">
                    <div class="form-group">
                        <label class="form-label" for="lokasi">Lokasi: <span class="text-danger">*</span></label>
                        <div class="form-control-wrap">
                            <input type="text" class="form-control" id="lokasi" name="lokasi" value="<?php echo e($profilAkademik->lokasi); ?>" placeholder="Masukkan lokasi anda" required>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6">
                    <div class="form-group">
                        <label class="form-label" for="pengalaman">Pengalaman: <span class="text-danger">*</span></label>
                        <div class="form-control-wrap">
                            <input type="text" class="form-control" id="pengalaman" name="pengalaman" value="<?php echo e($profilAkademik->pengalaman); ?>" placeholder="Masukkan pengalaman anda (bulan)" required>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6">
                    <div class="form-group">
                        <label class="form-label" for="etika">Etika: <span class="text-danger">*</span></label>
                        <div class="form-control-wrap">
                            <input type="text" class="form-control" id="etika" name="etika" value="<?php echo e($profilAkademik->etika); ?>" placeholder="Masukkan etika anda (Jumlah kumulasi Alpha Izin Sakit)" required>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6">
                    <div class="form-group">
                        <label class="form-label" for="ipk">IPK: <span class="text-danger">*</span></label>
                        <div class="form-control-wrap">
                            <input type="text" class="form-control" id="ipk" name="ipk" value="<?php echo e($profilAkademik->ipk); ?>" placeholder="Masukkan Nilai IPK (1-4)" required>
                        </div>
                    </div>
                </div>

                <div class="col-12">
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <a href="<?php echo e(route('profilAkademik.index')); ?>" class="btn btn-secondary">Kembali</a>
                    </div>
                </div>

            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\raki\Documents\raki4\pbl\raki\Internify\resources\views/mahasiswa/profilAkademik/edit.blade.php ENDPATH**/ ?>