<?php use Illuminate\Support\Str; ?>
<?php $__env->startSection('content'); ?>
<div class="card card-bordered">
    <div class="card-inner">
        <h5>Sertifikat Magang Tersedia</h5>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Judul</th>
                    <th>Deskripsi</th>
                    <th>Unduh</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $sertifikats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $sertifikat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($index+1); ?></td>
                    <td><?php echo e($sertifikat->judul); ?></td>
                    <td><?php echo e(Str::limit(strip_tags($sertifikat->deskripsi), 50)); ?></td>
                    <td><a href="<?php echo e(route('sertifikat.downloadMhs', $sertifikat->sertifikat_id)); ?>" class="btn btn-sm btn-primary">Unduh PDF</a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\raki\Documents\raki4\vsga\prod\Internify\resources\views/mahasiswa/sertifikatMahasiswa/index.blade.php ENDPATH**/ ?>