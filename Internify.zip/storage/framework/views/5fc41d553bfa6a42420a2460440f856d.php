


<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?>
<div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<?php if(session('error')): ?>
<div class="alert alert-danger"><?php echo e(session('error')); ?></div>
<?php endif; ?>

    <table border="1">
        <thead>
            <tr>
                <th>ID</th>
                <th>Judul Lowongan</th>
                <th>Periode Awal</th>
                <th>Periode Akhir</th>
                <th>Status</th>
                <th>Deskripsi</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $magangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->magang_id); ?></td>
                <td><?php echo e($item->lowongan->title); ?></td>
                <td><?php echo e($item->lowongan->period->start_date); ?></td>
                <td><?php echo e($item->lowongan->period->end_date); ?></td>
                <td><?php echo e($item->status); ?></td>
                <td><?php echo e($item->lowongan->description); ?></td>
                <td>
                    <form action="<?php echo e(route('hapusLamaran', $item->magang_id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" onclick="return confirm('Yakin ingin menghapus?')">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\raki\Documents\raki4\pbl\Internify\resources\views/magangApplication/indexMhs.blade.php ENDPATH**/ ?>