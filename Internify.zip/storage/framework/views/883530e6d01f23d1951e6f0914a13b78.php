<?php $__env->startSection('action'); ?>
    <li class="nk-block-tools-opt">
        <a href="<?php echo e(route('periodeMagang.create')); ?>" class="btn btn-primary">
            <em class="icon ni ni-plus"></em>
            <span>Tambah Periode</span>
        </a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <div class="card card-bordered card-preview">
        <div class="card-inner table-responsive">
            <table class="datatable-init-export nowrap nk-tb-list nk-tb-ulist" data-auto-responsive="false">
                <thead>
                    <tr class="nk-tb-item nk-tb-head">
                        <th class="nk-tb-col nk-tb-col-check">
                            <div class="custom-control custom-control-sm custom-checkbox notext">
                                <input type="checkbox" class="custom-control-input" id="uid">
                                <label class="custom-control-label" for="uid"></label>
                            </div>
                        </th>
                        <th class="nk-tb-col export-col"><span class="sub-text">Program Magang</span></th>
                        <th class="nk-tb-col export-col"><span class="sub-text">Tanggal Mulai</span></th>
                        <th class="nk-tb-col export-col"><span class="sub-text">Tanggal Berakhir</span></th>
                        <th class="nk-tb-col nk-tb-col-tools text-end"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $pegang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pegangs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="nk-tb-item">
                            <td class="nk-tb-col nk-tb-col-check">
                                <div class="custom-control custom-control-sm custom-checkbox notext">
                                    <input type="checkbox" class="custom-control-input" id="uid<?php echo e($pegangs->period_id); ?>">
                                    <label class="custom-control-label" for="uid<?php echo e($pegangs->period_id); ?>"></label>
                                </div>
                            </td>
                            <td class="nk-tb-col">
                                <span><?php echo e($pegangs->name); ?></span>
                            </td>
                            <td class="nk-tb-col">
                                <span><?php echo e($pegangs->start_date); ?></span>
                            </td>
                            <td class="nk-tb-col">
                                <span><?php echo e($pegangs->end_date); ?></span>
                            </td>
                            <td class="nk-tb-col nk-tb-col-tools">
                                <ul class="nk-tb-actions gx-1">
                                    <li class="nk-tb-action-hidden">
                                        <a href="#" class="btn btn-trigger btn-icon" data-bs-toggle="tooltip"
                                            data-bs-placement="top" title="Wallet">
                                            <em class="icon ni ni-wallet-fill"></em>
                                        </a>
                                    </li>
                                    <li class="nk-tb-action-hidden">
                                        <a href="#" class="btn btn-trigger btn-icon" data-bs-toggle="tooltip"
                                            data-bs-placement="top" title="Send Email">
                                            <em class="icon ni ni-mail-fill"></em>
                                        </a>
                                    </li>
                                    <li class="nk-tb-action-hidden">
                                        <a href="#" class="btn btn-trigger btn-icon" data-bs-toggle="tooltip"
                                            data-bs-placement="top" title="Suspend">
                                            <em class="icon ni ni-user-cross-fill"></em>
                                        </a>
                                    </li>
                                    <li>
                                        <div class="drodown">
                                            <a href="#" class="dropdown-toggle btn btn-icon btn-trigger"
                                                data-bs-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                            <div class="dropdown-menu dropdown-menu-end">
                                                <ul class="link-list-opt no-bdr">
                                                    <li><a href="#"><em class="icon ni ni-focus"></em><span>Quick
                                                                View</span></a></li>
                                                    <li><a href="#"><em class="icon ni ni-eye"></em><span>View
                                                                Details</span></a></li>
                                                    <li><a href="<?php echo e(route('periodeMagang.edit', $pegangs->period_id)); ?>"><em
                                                                class="icon ni ni-repeat"></em><span>Edit</span></a>
                                                    </li>
                                                    <li><a href="#"><em
                                                                class="icon ni ni-activity-round"></em><span>Activities</span></a>
                                                    </li>
                                                    <li class="divider"></li>
                                                    <li><a href="#"><em
                                                                class="icon ni ni-shield-star"></em><span>Reset
                                                                Pass</span></a></li>
                                                    <li><a href="#"><em class="icon ni ni-shield-off"></em><span>Reset
                                                                2FA</span></a></li>
                                                    <li><a href="<?php echo e(route('periodeMagang.destroy', $pegangs->period_id)); ?>"><em
                                                                class="icon ni ni-na"></em><span>Hapus
                                                                User</span></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\raki\Documents\raki4\pbl\Internify\resources\views/periodeMagang/index.blade.php ENDPATH**/ ?>