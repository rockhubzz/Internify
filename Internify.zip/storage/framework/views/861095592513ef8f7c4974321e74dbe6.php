<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
            <div class="col-sm-6 col-lg-4 col-xxl-3" style="width: 100%">
                <div class="card card-bordered h-100">
                    <div class="card-inner">
                        <h4><?php echo e($feedback->judul_feedback); ?></h4>
                        <?php for($i=0; $i<$feedback->rating; $i++): ?>
                            <i class="icon ni ni-star-fill"></i>
                        <?php endfor; ?>

                        <p><?php echo $feedback->feedback; ?></p>

                        <div class="mt-3">
                        <a href="<?php echo e(route('feedback-edit', $feedback->feedback_id)); ?>" class="btn btn-primary">Edit Feedback</a>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\raki\Documents\raki4\pbl\raki\Internify\resources\views/mahasiswa/feedbackMagang/index.blade.php ENDPATH**/ ?>