<?php $__env->startSection('content'); ?>
    <div class="card card-bordered card-preview">
        <div class="card-inner">
            <form action="<?php echo e(route('companies.update', $company->company_id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?> 
                <div class="row g-4">
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="form-label" for="name">Nama Lengkap:</label>
                            <div class="form-control-wrap">
                                <input type="text" class="form-control" id="name" name="name"
                                    value="<?php echo e($company->user->name ?? ''); ?>" required>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="form-label" for="username">Username:</label>
                            <div class="form-control-wrap">
                                <input type="text" class="form-control" id="username" name="username"
                                    value="<?php echo e($company->user->username ?? ''); ?>" required>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="form-label" for="email">Email:</label>
                            <div class="form-control-wrap">
                                <input type="text" class="form-control" id="email" name="email"
                                    value="<?php echo e($company->user->email ?? ''); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="form-label" for="password">Password:</label>
                            <div class="form-control-wrap">
                                <input type="password" class="form-control" id="password" name="password"
                                    placeholder="Kosongkan jika tidak ingin diubah">
                                <small class="form-note">Kosongkan field ini jika Anda tidak ingin mengubah
                                    password.</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="form-label" for="no_telp">No Telepon:</label>
                            <div class="form-control-wrap">
                                <input type="text" class="form-control" id="no_telp" name="no_telp"
                                    value="<?php echo e($company->user->no_telp ?? ''); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="form-label">Industri:</label>
                            <div class="form-control-wrap">
                                <select class="form-select js-select2" data-search="on" name="industry" id="industry">
                                    <option value="default_option"
                                        <?php echo e($company->industry == 'default_option' ? 'selected' : ''); ?>>Default Option
                                    </option>
                                    <option value="Sales" <?php echo e($company->industry == 'Sales' ? 'selected' : ''); ?>>Sales
                                    </option>
                                    <option value="Marketing" <?php echo e($company->industry == 'Marketing' ? 'selected' : ''); ?>>
                                        Marketing</option>
                                    <option value="Teknologi" <?php echo e($company->industry == 'Teknologi' ? 'selected' : ''); ?>>
                                        Teknologi</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="form-label" for="alamat">Alamat:</label>
                            <div class="form-control-wrap">
                                <input type="text" class="form-control" id="alamat" name="alamat"
                                    value="<?php echo e($company->user->alamat ?? ''); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">Update</button>
                            <a href="<?php echo e(route('companies.index')); ?>" class="btn btn-secondary">Kembali</a>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\raki\Documents\raki4\pbl\raki\Internify\resources\views/admin/company/edit.blade.php ENDPATH**/ ?>