<title>Tambah Program Studi</title>

<form method="POST" action="<?php echo e(url('/prodi/')); ?>">
    <?php echo csrf_field(); ?>
    

    <div>
        <label>Nama Prodi</label>
        <input type="text" name="name" required>

        <button type="submit">Simpan</button>
    </div>
</form>
<?php /**PATH C:\Users\raki\Documents\raki4\pbl\Internify\resources\views/prodi/create.blade.php ENDPATH**/ ?>