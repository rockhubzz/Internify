<?php $__env->startSection('action'); ?>
    <li class="nk-block-tools-opt">
        <a href="<?php echo e(route('mahasiswa.create')); ?>" class="btn btn-primary">
            <em class="icon ni ni-plus"></em>
            <span>Tambah Mahasiswa</span>
        </a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <div class="card card-bordered card-preview">
        <div class="card-inner">
            <table class="datatable-init-export nowrap nk-tb-list nk-tb-ulist" data-auto-responsive="false">
                <thead>
                    <tr class="nk-tb-item nk-tb-head">
                        <th class="nk-tb-col export-col"><span class="sub-text">User</span></th>
                        <th class="nk-tb-col tb-col-mb export-col"><span class="sub-text">NIM</span></th>
                        <th class="nk-tb-col tb-col-lg export-col"><span class="sub-text">Jurusan</span></th>
                        <th class="nk-tb-col tb-col-lg export-col"><span class="sub-text">Alamat</span></th>
                        <th class="nk-tb-col tb-col-md export-col"><span class="sub-text">Telepon</span></th>
                        <th class="nk-tb-col nk-tb-col-tools text-end">
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $mahasiswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="nk-tb-item">
                            <td class="nk-tb-col">
                                <div class="user-card">
                                    <div class="user-avatar bg-teal-dim d-none d-sm-flex">
                                        <?php if($mhs->user->image): ?>
                                            <img src="<?php echo e(Storage::url('images/users/' . $mhs->user->image)); ?>"
                                                alt="<?php echo e($mhs->user->name); ?>">
                                        <?php else: ?>
                                            <span>
                                                <?php echo e(strtoupper(collect(explode(' ', $mhs->user->name))->map(fn($word) => $word[0])->take(2)->implode(''))); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="user-info">
                                        <span class="tb-lead"><?php echo e($mhs->user->name); ?><span
                                                class="dot dot-success d-md-none ms-1"></span></span>
                                        <span><?php echo e($mhs->user->email); ?></span>
                                    </div>
                                </div>
                            </td>
                            <td class="nk-tb-col tb-col-mb">
                                <span><?php echo e($mhs->nim); ?></span>
                            </td>
                            <td class="nk-tb-col tb-col-lg" data-order="Email Submited - Kyc More Info">
                                <span><?php echo e($mhs->prodi->name); ?></span>
                            </td>
                            <td class="nk-tb-col tb-col-lg">
                                <span><?php echo e($mhs->user->alamat); ?></span>
                            </td>
                            <td class="nk-tb-col tb-col-md">
                                <span><?php echo e($mhs->user->no_telp); ?></span>
                            </td>
                            <td class="nk-tb-col nk-tb-col-tools">
                                <ul class="nk-tb-actions gx-1">
                                    <li>
                                        <div class="drodown">
                                            <a href="#" class="dropdown-toggle btn btn-icon btn-trigger"
                                                data-bs-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                            <div class="dropdown-menu dropdown-menu-end">
                                                <ul class="link-list-opt no-bdr">
                                                    <li><a href="#"><em class="icon ni ni-eye"></em><span>Lihat
                                                                Detail</span></a></li>
                                                    <li><a href="<?php echo e(route('mahasiswa.edit', $mhs->mahasiswa_id)); ?>"><em
                                                                class="icon ni ni-repeat"></em><span>Edit</span></a>
                                                    </li>

                                                    <li class="divider"></li>
                                                    <li><a href="<?php echo e(route('mahasiswa.destroy', $mhs->mahasiswa_id)); ?>"><em
                                                                class="icon ni ni-trash"></em><span>Hapus
                                                                Mahasiswa</span></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </td>
                        </tr><!-- .nk-tb-item  -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\raki\Documents\raki4\pbl\raki\Internify\resources\views/admin/mahasiswa/index.blade.php ENDPATH**/ ?>